// routes/app.routes.js
"use strict";


const ctrl = require('../controllers/my-controller.controller.js');
module.exports = function (app) {
    app.get('api/v1/getdata', ctrl.getData); //Automatically passes req/res.
};