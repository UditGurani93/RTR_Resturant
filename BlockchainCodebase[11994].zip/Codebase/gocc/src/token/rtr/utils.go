package main


import (
	"bytes"
	// The shim package
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"fmt"
	// Conversion functions
	"strconv"
	
   // JSON Encoding
   "encoding/json"
 )

// ===========================================================================================
// constructQueryResponseFromIterator constructs a JSON array containing query results from
// a given result iterator
// ===========================================================================================
func ConstructQueryResponseFromPartialIterator(stub shim.ChaincodeStubInterface, resultsIterator shim.StateQueryIteratorInterface, indexName string) (*bytes.Buffer, error) {
	// buffer is a JSON array containing QueryResults
	var buffer bytes.Buffer
	buffer.WriteString("[")
	fmt.Println("construct")
	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		// Split the composite key and send it as part of the result set
		_, arr, _ := stub.SplitCompositeKey(queryResponse.GetKey())
		fmt.Println(arr)
		key1, err := stub.CreateCompositeKey(indexName, arr)
		
		dataAsBytes, _ := stub.GetState(key1)
		fmt.Println(key1)
		buffer.WriteString(" [" + string(dataAsBytes) + "] ")
		bArrayMemberAlreadyWritten = true
	
	}
	resultsIterator.Close()
	buffer.WriteString("]")

	return &buffer, nil
}


// // =========================================================================================
// // getQueryResultForQueryString executes the passed in query string.
// // Result set is built and returned as a byte array containing the JSON results.
// // =========================================================================================
// func getQueryResultForQueryStringPrivate(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

// 	fmt.Printf("- getQueryResultForQueryString queryString:\n%s\n", queryString)

// 	resultsIterator, err := stub.GetPrivateDataQueryResult("collectionMarbles", queryString)
// 	if err != nil {
// 		return nil, err
// 	}
// 	defer resultsIterator.Close()

// 	// buffer is a JSON array containing QueryRecords
// 	var buffer bytes.Buffer
// 	buffer.WriteString("[")

// 	bArrayMemberAlreadyWritten := false
// 	for resultsIterator.HasNext() {
// 		queryResponse, err := resultsIterator.Next()
// 		if err != nil {
// 			return nil, err
// 		}
// 		// Add a comma before array members, suppress it for the first array member
// 		if bArrayMemberAlreadyWritten == true {
// 			buffer.WriteString(",")
// 		}
// 		buffer.WriteString("{\"Key\":")
// 		buffer.WriteString("\"")
// 		buffer.WriteString(queryResponse.Key)
// 		buffer.WriteString("\"")

// 		buffer.WriteString(", \"Record\":")
// 		// Record is a JSON object, so we write as-is
// 		buffer.WriteString(string(queryResponse.Value))
// 		buffer.WriteString("}")
// 		bArrayMemberAlreadyWritten = true
// 	}
// 	buffer.WriteString("]")

// 	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

// 	return buffer.Bytes(), nil
// }


// func getQueryResultForQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

// 	fmt.Printf("- getQueryResultForQueryString queryString:\n%s\n", queryString)

// 	resultsIterator, err := stub.GetQueryResult(queryString)
// 	if err != nil {
// 		return nil, err
// 	}
// 	defer resultsIterator.Close()

// 	buffer, err := constructQueryResponseFromIterator(resultsIterator)
// 	if err != nil {
// 		return nil, err
// 	}

// 	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

// 	return buffer.Bytes(), nil
// }


// ===========================================================================================
// constructQueryResponseFromIterator constructs a JSON array containing query results from
// a given result iterator
// ===========================================================================================
func constructQueryResponseFromQueryIterator(resultsIterator shim.StateQueryIteratorInterface) (*bytes.Buffer, error) {
	// buffer is a JSON array containing QueryResults
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")
	return &buffer, nil
}


// =========================================================================================
// getQueryResultForQueryString executes the passed in query string.
// Result set is built and returned as a byte array containing the JSON results.
// =========================================================================================
func getQueryResultForQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

	fmt.Printf("- getQueryResultForQueryString queryString:\n%s\n", queryString)

	resultsIterator, err := stub.GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	buffer, err := constructQueryResponseFromIterator(resultsIterator)
	if err != nil {
		return nil, err
	}

	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

	return buffer.Bytes(), nil
}


// ===========================================================================================
// constructQueryResponseFromIterator constructs a JSON array containing query results from
// a given result iterator
// ===========================================================================================
func constructQueryResponseFromIterator(resultsIterator shim.StateQueryIteratorInterface) (*bytes.Buffer, error) {
	// buffer is a JSON array containing QueryResults
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	return &buffer, nil
}


func getCustomerRestdetailsByuserID(stub shim.ChaincodeStubInterface, restaurantNo string, customerID string) ([]byte, error) {
	var userReservation = []UserReservation{}
	var buffer bytes.Buffer
	var user = []User{}
	
	stringQry := `{
		"selector": {
		   "objectType": "UserReservation",
		   "restaurantNo": "`+ restaurantNo +`",
		   "userID": "`+ customerID +`",
		   "reservationStatus": "CheckOut Completed"
		}
	 }`
	userRestResultsIterator, err := stub.GetQueryResult(stringQry)
	if err != nil {
		return nil, err
	}
	bufferBytes, err := constructQueryResponseFromQueryIterator(userRestResultsIterator)
	if err != nil {
		return nil, err
	}
	json.Unmarshal([]byte(bufferBytes.String()), &userReservation)
	if userReservation !=nil {
		// Get User details by
		userBufferBytes, err := getUserDetailsByUserId(stub, customerID)
		if err != nil {
			return nil , err
		}
		json.Unmarshal(userBufferBytes, &user)
		// fmt.Println(string(userBufferBytes))
		// fmt.Println(user[0])
		
		buffer.WriteString("{\"userID\" : \"")
		buffer.WriteString(user[0].UserID)
		buffer.WriteString("\",")
		buffer.WriteString(" \"userName\" : \"")
		buffer.WriteString(user[0].UserName)
		buffer.WriteString("\",")
		buffer.WriteString(" \"memberShip\" : \"")
		buffer.WriteString(user[0].MemberShip)
		buffer.WriteString("\",")


		//buffer.WriteString(string(userBufferBytes))
		// buffer.WriteString(",")
		// buffer.WriteString(bufferBytes.String())
		// buffer.WriteString(",")

		userResrvations := make([]string, len(userReservation))
		i := 0
		for i < len(userReservation){	
			userResrvations = append(userResrvations, strconv.Itoa(userReservation[i].ReservationNo))
			//userResrvations = strconv.Itoa(userReservation[i].ReservationNo) 
			
			i++
		}
		userResrvations = userResrvations[i:]
		userReservationCount := len(userResrvations)
		buffer.WriteString(" \"UserReservatons\":")
		userResrvationsJson, _ := json.Marshal(userResrvations)
		buffer.WriteString( string(userResrvationsJson))
		buffer.WriteString(", \"totalUserReservaton\":")
		buffer.WriteString( strconv.Itoa(userReservationCount))
		buffer.WriteString("}")
	}
	return buffer.Bytes(), nil
	
	
	// reservationList, err := getDetailsFromQuery(stub, objectUserReservation, "restaurantNo", restaurantNo)
	// if err != "" {			
	// 	return shim.Error(err)
	// }
	// json.Unmarshal(reservationList, &userReservation)
	// i := 0
	
	// for i < len(userReservation) {
	// 	getReservationDetailsByReservationNo(stub, reservationNo)
	// }

}

func removeDuplicatesUnordered(elements []string) []string {
    encountered := map[string]bool{}

    // Create a map of all unique elements.
    for v:= range elements {
        encountered[elements[v]] = true
    }

    // Place all keys from the map into a slice.
    result := []string{}
    for key, _ := range encountered {
        result = append(result, key)
    }
    return result
}

func getEntityDetailsByDocName(stub shim.ChaincodeStubInterface, indexName string, args []string) ([]byte, error, int) {

	// Gets the state by partial query key
	QryIterator, err := stub.GetStateByPartialCompositeKey(indexName, args)
	if err != nil {
		fmt.Printf("Error in getting by range=" + err.Error())
		return nil, err, 0
	}
	var resultJSON = "["
	counter := 0
	var userAsBytes []byte
	// Iterate to read the keys returned
	for QryIterator.HasNext() {
		// Hold pointer to the query result
	//	var resultKV *queryresult.KV
		var err error

		// Get the next element
		resultKV, err := QryIterator.Next()
		if err != nil {
			fmt.Println("Err=" + err.Error())
			return nil, err, 0
		}

		// Split the composite key and send it as part of the result set
		_, arr, _ := stub.SplitCompositeKey(resultKV.GetKey())
		fmt.Println(arr)
		key1, err := stub.CreateCompositeKey(indexName, arr)
		
		userAsBytes, _ = stub.GetState(key1)
		if counter > 0 {
			resultJSON =  resultJSON + ","
		}
		resultJSON +=  string(userAsBytes)
		counter++

	}
	// Closing
	QryIterator.Close()

	resultJSON += "]"
	//resultJSON = "Counter=" + strconv.Itoa(counter) + "  " + resultJSON
	fmt.Println("Done.")
	return []byte(resultJSON), nil, counter
}



func getUserDetailsByUserId(stub shim.ChaincodeStubInterface, userID string) ([]byte, error) {

	stringQry := `{
		"selector": {
		"objectType": "User",
		"userID": "`+userID+`"
		}
	}`
	userReservationResultsIterator, err := stub.GetQueryResult(stringQry)
	if err != nil {
		return nil, err
	}
	buffer, err := constructQueryResponseFromQueryIterator(userReservationResultsIterator)
	if err != nil {
		return nil, err
	}
	//_ = json.Unmarshal(buffer, &data)
	// i := 0
	// for i < len(data) {
	// 	reservationNo[i] = data[i].ReservationNo
	// }
	// fmt.Println(reservationNo)
	return buffer.Bytes(), nil
}


func getUserResrvDetailsByUserId(stub shim.ChaincodeStubInterface, userID string) ([]byte, error) {

	stringQry := `{
		"selector": {
		"objectType": "UserReservation",
		"userID": "`+userID+`"
		}
	}`
	userReservationResultsIterator, err := stub.GetQueryResult(stringQry)
	if err != nil {
		return nil, err
	}
	buffer, err := constructQueryResponseFromQueryIterator(userReservationResultsIterator)
	if err != nil {
		return nil, err
	}
	//_ = json.Unmarshal(buffer, &data)
	// i := 0
	// for i < len(data) {
	// 	reservationNo[i] = data[i].ReservationNo
	// }
	// fmt.Println(reservationNo)
	return buffer.Bytes(), nil
}

 func getAllReservationAndSUserIDBySeatID(stub shim.ChaincodeStubInterface, restSeatNo string) (string, string) {
	var seatReservationDetails = []SeatReservationDetails{}
	var userReservation UserReservation

	seatReservationDetailsResp, _ := getDetailsFromQuery(stub, objectTypeSeatReservationDetails, "restSeatNo", restSeatNo )
	json.Unmarshal([]byte(seatReservationDetailsResp), &seatReservationDetails)
	reservationNo := seatReservationDetails[0].ReservationNo

	indexName := "objectType~reservationNo"
	userReservationIndexKey, _ := stub.CreateCompositeKey(indexName, []string{objectUserReservation, reservationNo})
	userReservationAsByte, _ := stub.GetState(userReservationIndexKey)
	fmt.Println(string(userReservationAsByte))
	
	json.Unmarshal([]byte(userReservationAsByte), &userReservation)
	userID := userReservation.UserID

	return reservationNo, userID

 }

 
 func getUserDetailsByUserID(stub shim.ChaincodeStubInterface, userID string) ([]byte, error) {
	indexName := "objectType~userID"
	userIndexKey, _ := stub.CreateCompositeKey(indexName, []string{objectUserReservation, userID})
	userAsByte, err := stub.GetState(userIndexKey)
	return userAsByte, err
		
 }
