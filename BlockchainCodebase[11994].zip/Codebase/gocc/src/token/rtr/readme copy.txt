Launch the environment
======================
Dev  mode:     ca-dev-init-covid.sh  

Try out v1/token
================
#1  



cat /etc/GetHistoryOfSeatBySeatNo

127.0.0.1       ncr-peer1.ncr.com
127.0.0.1       chipotle-peer1.chipotle.com
127.0.0.1       orderer.ncr.com
127.0.0.1       murphy-peer1.murphy.com
127.0.0.1       riogrande-peer1.riogrande.com
127.0.0.1       metropolitan-peer1.metropolitan.com
127.0.0.1       firehousesubs-peer1.firehousesubs.com
127.0.0.1       leospizzaria-peer1.leospizzaria.com
127.0.0.1       montanagrill-peer1.montanagrill.com
127.0.0.1       postgresql
127.0.0.1       explorer




<<Terminal #1>>  


. set-env-covid.sh ncr
set-chain-env.sh   -n rtrTest   -p token/rtr  -v 1.0  -c '{"Args": ["init"]}'  


chain.sh    install 
chain.sh    instantiate                            

. set-env-covid.sh ncr
set-chain-env.sh   -n rtrTest   -p token/rtr  -v 3.1 -c '{"Args": ["init"]}'  

chain.sh    install 
chain.sh upgrade

 <<Observe terminal#2>>

Checkout explorer - you should see 1 transaction against the chaicode 'token'

#4

<<Terminal #1>>

- Setup and execute the invoke & query API
set-chain-env.sh  -i '{"Args": ["InitUser"] }'
chain.sh  invoke                                 


set-chain-env.sh  -i '{"Args": ["InitRestaurant"] }'
chain.sh  invoke    


set-chain-env.sh  -i '{"Args": ["InitRestaurantOffer"] }'
chain.sh  invoke

set-chain-env.sh  -i '{"Args": ["UploadCertificationByRestaurantNo", "RES0"] }'
chain.sh  invoke   

queryEntityByPartialKey


set-chain-env.sh  -q '{"Args": ["queryAllUserPartial","SeatDetails","RES0",20] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["queryAllUserPartial","SeatDetails","RES0",20] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["queryAllUserPartial","SeatDetails","Chip23" ]}' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["FindAvailableSeat","RES0"] }' 
chain.sh  query


Restaurant, User , SeatDetails
// const ResNoSeatNoIndexKey = "restaurantNo~seatNo"
// const objectTypeSeatReservation = "SeatReservation"
// const objectTypeSeatReservationDetails = "SeatReservationDetails"
// const objectTypeReservationDetails = "ReservationDetails"
// const objectUserReservation = "UserReservation"
// const objectTypeSeatDetails = "SeatDetails"
	


queryEntityByPartialKey
set-chain-env.sh  -q '{"Args": ["queryEntityByPartialKey","RestaurantOffers"] }' 
chain.sh  query


SeatReservation


set-chain-env.sh  -q '{"Args": ["GetRestaurantsListWithDetails"] }' 
chain.sh  query

InitRestaurantOffer
// const objectTypeSeatReservationDetails = "SeatReservationDetails"
// const objectTypeReservationDetails = "ReservationDetails"
// const objectUserReservation = "UserReservation"
// const objectTypeSeatDetails = "SeatDetails"
	
set-chain-env.sh  -i '{"Args": ["SeatReservation", "USER1", "Chip1","RES0", "Chip1", "Chip2","Chip3"] }'
chain.sh  invoke   
 
set-chain-env.sh  -i '{"Args": ["SeatReservation", "USER1", "Chip1","RES0", "Chip1"] }'
chain.sh  invoke  

set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","UserReservation", "reservationNo", "25" ] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","SeatReservationDetails", "reservationNo", "35" ] }' 
chain.sh  query


set-chain-env.sh  -i '{"Args": ["UserCheckIn", "2", "true"] }'
chain.sh  invoke   


set-chain-env.sh  -i '{"Args": ["UserCheckOut", "2"] }'
chain.sh  invoke  

set-chain-env.sh  -i '{"Args": ["SeatSanitizeStart", "2"] }'
chain.sh  invoke  

set-chain-env.sh  -i '{"Args": ["SeatSanitizeEnd", "2"] }'
chain.sh  invoke 

QueryAllReservationByUsedID

set-chain-env.sh  -q '{"Args": ["QueryAllReservationByUsedID","USER3"] }' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["GetAllCustomerByRestaurantID","RES1"] }' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["GetReservationDeatilsByResvNo","1"] }' 
chain.sh  query

giveFeedbackByReservationNo


set-chain-env.sh  -i '{"Args": ["giveFeedbackByReservationNo","2", "true", "false","true","true","true","4"] }' 
chain.sh  invoke
getRestaurantRatingByRestaurantNo

set-chain-env.sh  -q '{"Args": ["getRestaurantRatingByRestaurantNo","RES1"] }' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["GetHistoryOfSeatBySeatNo","14" ] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["GetHistoryOfSeatBySeatNo","Murp5" ] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["GetHistoryOfReservationByReservationNo","RES1"] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["GetHistoryOfReservationByReservationNo","35"] }' 
chain.sh  query
GetRestaurantSeatStatusbyRestaurantNo

set-chain-env.sh  -q '{"Args": ["GetRestaurantSeatStatusbyRestaurantNo","RES1" ] }' 
chain.sh  query

set-chain-env.sh  -i '{"Args": ["UploadCertificationByRestaurantNo","RES1" ] }' 
chain.sh  invoke


set-chain-env.sh  -i '{"Args": ["InitRestaurantOffer" ] }' 
chain.sh  invoke


set-chain-env.sh  -q '{"Args": ["GetAllOffersByUserIDRestaurantNo","USER1" ,"RES0" ] }' 
chain.sh  query



set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","UserReservation", "restaurantNo", "RES1" ] }' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","UserReservation", "userID", "USER1" ] }' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","ReservationDetails", "reservationNo", "25" ] }' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","SeatReservationDetails", "", "" ] }' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","SeatReservationDetails", "restSeatNo", "Chip2" ] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","NCRRestaurantCertification", "restaurantNo", "RES1" ] }' 
chain.sh  query

UploadCertificationByRestaurantNo
set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","SeatDetails", "restSeatNo", "Chip2" ] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","SeatDetails", "restSeatNo", "Murp1" ] }' 
chain.sh  query

set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","SeatDetails",  "restaurantNo", "RES1"] }' 
chain.sh  query


set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","RestaurantOffers", "restaurantNo", "RES0" ] }' 
chain.sh  query
