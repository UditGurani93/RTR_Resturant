package main

import (
   "fmt"

   "bytes"
   // The shim package
   "github.com/hyperledger/fabric/core/chaincode/shim"

   // peer.Response is in the peer package
   "github.com/hyperledger/fabric/protos/peer"

   // Conversion functions
   "strconv"

   "time"

   // JSON Encoding
   "encoding/json"
)


//const ResNoSeatNoIndexKey = "restaurantNo~seatNo"
const objectTypeSeatReservation = "SeatReservation"
const objectTypeSeatReservationDetails = "SeatReservationDetails"
//const objectTypeReservation = "ReservationDetails"
const objectUserReservation = "UserReservation"
//const objectTypeSeatDetails = "SeatDetails"
var seatDetails SeatDetails	
const objectTypeReservationDetails = "ReservationDetails"
const objectTypeUserRestaurantFeedback = "UserRestaurantFeedback"



func (rtr *ReturntoRestaurantChaincode) FindAvailableSeat(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting User ID, RestaurantNo")
	}	
	restaurantNo := args[0]
	buffer, err := checkForAvailableSeat(stub, restaurantNo)

	if buffer != nil {
		return shim.Success(buffer)
	}

	return shim.Error(err)
}

func (rtr *ReturntoRestaurantChaincode) SeatReservation(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	if len(args) < 3 {
		return shim.Error("Incorrect number of arguments. Expecting User ID, RestaurantNo, Seat No")
	}
	
	userID := args[0]
	
	restaurantNo := args[2]
	
	var restSeatNo []string =args[3:]
	// seatNo := args[2]
	// var userBodyTemp = ""
	// var userCheckInTime =""
	// // var jsonResp string
	// // var userReservation	UserReservation
	// if args[3] != "" {
	// 	userBodyTemp = args[3]
	// }

	// if args[4] != "" {
	// 	userCheckInTime = args[4]
	// }
	qryString := `{
		"selector": {
		   "objectType": "UserReservation"
		},
		"sort": [
		   {
			  "reservationNo": "desc"
		   }
		],
		"limit": 1
	 }`

	 fmt.Printf("Query JSON=%s \n", qryString)
	 maxReservationNo := 1
	 //stringreservationNo := ""
	resultsIterator, err := stub.GetQueryResult(qryString)
	if err != nil {
		return shim.Error(err.Error())
	}
	
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}

		bytes := queryResponse.GetValue()
		var data  UserReservation
		_ = json.Unmarshal(bytes, &data)
		fmt.Println(data)
		//stringreservationNo = data.ReservationNo 
		intReservationNo := data.ReservationNo 
		//response = string(queryResponse.Value)
		fmt.Println(intReservationNo)
		//maxReservationNo, _ = strconv.Atoi(stringreservationNo)
		maxReservationNo = intReservationNo + 1
		break
		
	}
	fmt.Println( maxReservationNo)
	
	resultsIterator.Close()
	reservationNo := strconv.Itoa(maxReservationNo)
	// indexName := "objectType~reservationNo"
	// userReservationIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectUserReservation, reservationNo})
	// userReservationAsByte, err := stub.GetState(userReservationIndexKey)

	// currentTime := time.Now()
	// userCheckInTime = currentTime.Format("2006-Jan-02 15:04:05")

	// if err != nil {
	// 	errstr := "Failed to get state for " + reservationNo + " : "+ err.Error()
	// 	return shim.Error(errstr)
	// } else if userReservationAsByte == nil {
	// 	jsonResp = "{\"Error\":\"Reservation does not exist: " + reservationNo + "\"}"
	// 	return shim.Error(jsonResp)
	// }
	// err = json.Unmarshal([]byte(userReservationAsByte), &userReservation)
	// if err != nil {
	// 	jsonResp = "{\"Error\":\"Failed to decode JSON of: " + reservationNo + "\"}"
	// 	return shim.Error(jsonResp)
	// }

	//seatIndexName := "objectType~restaurantNo~seatNo"
	// // // seatIndexName :=  "objectType~restSeatNo"
	//seatDetailskey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restaurantNo, seatNo})
	
	// // // seatDetailskey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo})
	// // // seatDetailsAsByte, err := stub.GetState(seatDetailskey)
	// // // if err != nil {
	// // // 	return shim.Error(err.Error())
	// // // }
	// // // _ = json.Unmarshal([]byte(seatDetailsAsByte), &seatDetails)
	// // // restSeatNo := seatDetails.RestSeatNo
	
	var buffer bytes.Buffer
	buffer.WriteString("[")
	reservationDetails,_ := ConfirmReservation(stub, restSeatNo, userID, reservationNo, restaurantNo )
	if reservationDetails == nil{
		shim.Error("Reservation not successfull")
	}
	fmt.Println(restSeatNo)
	seatDetails, _ := SeatConfirmation(stub, reservationNo, restSeatNo)
	if reservationDetails == nil{
		shim.Error("Seat reservation not successfull")
	}
	
	buffer.WriteString("{\"reservationDetails\":")
	buffer.WriteString("\"")
	buffer.WriteString(string(reservationDetails))
	buffer.WriteString("\"")

	buffer.WriteString(", \"seatDetails\":")
	// Record is a JSON object, so we write as-is
	buffer.WriteString(string(seatDetails))
	buffer.WriteString("}")

	buffer.WriteString("]")

	
	fmt.Printf("- reservationDetails seatDetails:\n%s\n", buffer.String())
	return shim.Success(buffer.Bytes())
}

func (rtr *ReturntoRestaurantChaincode) UserCheckIn(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	reservationNo := args[0]
	userBodyTemp := args[1]
	var reservationDetails ReservationDetails
	var userReservation	UserReservation
	var jsonResp string
	var seatReservationDetails = []SeatReservationDetails{}

	indexName := "objectType~reservationNo"
	userReservationIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectUserReservation, reservationNo})
	userReservationAsByte, err := stub.GetState(userReservationIndexKey)
	currentTime := time.Now()
	userCheckInTime := currentTime.Format("2006-Jan-02 15:04:05")

	if err != nil {
		errstr := "Failed to get state for " + reservationNo + " : "+ err.Error()
		return shim.Error(errstr)
	} else if userReservationAsByte == nil {
		jsonResp = "{\"Error\":\"Reservation does not exist: " + reservationNo + "\"}"
		return shim.Error(jsonResp)
	}
	err = json.Unmarshal([]byte(userReservationAsByte), &userReservation)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of: " + reservationNo + "\"}"
		return shim.Error(jsonResp)
	}
	reservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeReservationDetails, reservationNo})
	reservationDetailsAsByte, err := stub.GetState(reservationDetailsIndexKey)
	_ = json.Unmarshal([]byte(reservationDetailsAsByte), &reservationDetails)
	
	seatDetIndexName := "objectType~reservationNo~restSeatNo"
	 // seatReservationDetails, err := stub.GetState(seatReservationDetailsIndexKey)
	getSeatReservationDetails, _ := getDetailsFromQuery(stub, objectTypeSeatReservationDetails, "reservationNo", reservationNo)
	_ = json.Unmarshal([]byte(getSeatReservationDetails), &seatReservationDetails)
	varuserbodyTemp := userBodyTemp
	if varuserbodyTemp == "false" {
		userReservation.ReservationStatus = "User Body Temperature is above 45 celsius"
		userReservationasBytes, err := json.Marshal(userReservation)
		if err != nil {
			return shim.Error(err.Error())
		}
		stub.PutState(userReservationIndexKey, userReservationasBytes)
		
		reservationDetails.UserBodyTemperature  = userBodyTemp
		reservationDetailsAsBytes, _ := json.Marshal(reservationDetails)
		stub.PutState(reservationDetailsIndexKey, reservationDetailsAsBytes)
		i := 0
		for i < len(seatReservationDetails) {
			seatReservationDetailsIndexKey, _ := stub.CreateCompositeKey(seatDetIndexName, []string{objectTypeSeatReservationDetails, reservationNo, seatReservationDetails[i].RestSeatNo})
	
			seatReservationDetails[i].ResrvSeatStatus = "User Body Temperature is above 45 celsius"
			seatReservationDetails[i].Timestamp = userCheckInTime
			seatReservationDetailsAsBytes, _ := json.Marshal(seatReservationDetails[i])
			stub.PutState(seatReservationDetailsIndexKey, seatReservationDetailsAsBytes)
			
			i++
		}
		return shim.Error("Your Body Temperature is High")
	}
	
	i := 0
	for i < len(seatReservationDetails) {
		seatReservationDetailsIndexKey, _ := stub.CreateCompositeKey(seatDetIndexName, []string{objectTypeSeatReservationDetails, reservationNo, seatReservationDetails[i].RestSeatNo})
	
		seatReservationDetails[i].ResrvSeatStatus = "CheckedIn"
		seatReservationDetails[i].Timestamp = userCheckInTime
		seatReservationDetailsAsBytes, _ := json.Marshal(seatReservationDetails[i])
		stub.PutState(seatReservationDetailsIndexKey, seatReservationDetailsAsBytes)
		
		i++	
	}


	userReservation.ReservationStatus = "CheckedIn"
	userReservationasBytes, err := json.Marshal(userReservation)
	if err != nil {
		return shim.Error(err.Error())
	}
	fmt.Println(string(userReservationasBytes))
		
	stub.PutState(userReservationIndexKey, userReservationasBytes)
	
	reservationDetails.UserBodyTemperature  = userBodyTemp
	reservationDetails.UserCheckInTime = userCheckInTime
	reservationDetailsAsBytes, _ := json.Marshal(reservationDetails)
		
	stub.PutState(reservationDetailsIndexKey, reservationDetailsAsBytes)

	//seatReservationAsBytes, _  := stub.GetState(reservationNo)
	return shim.Success(reservationDetailsAsBytes)
}


func (rtr *ReturntoRestaurantChaincode) UserCheckOut(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	reservationNo := args[0]
	var reservationDetails ReservationDetails
	var userReservation	UserReservation
	var seatReservationDetails = []SeatReservationDetails{}

	indexName := "objectType~reservationNo"
	var jsonResp string
	userReservationIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectUserReservation, reservationNo})
	userReservationAsByte, _  := stub.GetState(userReservationIndexKey)

	currentTime := time.Now()
	userCheckOutTime := currentTime.Format("2006-Jan-02 15:04:05")

	if err != nil {
		errstr := "Failed to get state for " + reservationNo + " : "+ err.Error()
		return shim.Error(errstr)
	} else if userReservationAsByte == nil {
		jsonResp = "{\"Error\":\"Reservation does not exist: " + reservationNo + "\"}"
		return shim.Error(jsonResp)
	}
	err = json.Unmarshal([]byte(userReservationAsByte), &userReservation)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of: " + reservationNo + "\"}"
		return shim.Error(jsonResp)
	}
	userReservation.ReservationStatus = "CheckOut Completed"
	userReservationasBytes, err := json.Marshal(userReservation)
	if err != nil {
		return shim.Error(err.Error())
	}
	stub.PutState(userReservationIndexKey, userReservationasBytes)
	seatDetIndexName := "objectType~reservationNo~restSeatNo"
	// seatReservationDetails, err := stub.GetState(seatReservationDetailsIndexKey)
	getSeatReservationDetails, _ := getDetailsFromQuery(stub, objectTypeSeatReservationDetails, "reservationNo", reservationNo)
   _ = json.Unmarshal([]byte(getSeatReservationDetails), &seatReservationDetails)
  
	// seatReservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservationDetails, reservationNo})
	// seatReservationDetailsAsByte, err := stub.GetState(seatReservationDetailsIndexKey)
	// _ = json.Unmarshal([]byte(seatReservationDetailsAsByte), &seatReservationDetails)
	i := 0
	for i < len(seatReservationDetails){
		seatReservationDetailsIndexKey, _ := stub.CreateCompositeKey(seatDetIndexName, []string{objectTypeSeatReservationDetails, reservationNo,seatReservationDetails[i].RestSeatNo})
		seatReservationDetails[i].ResrvSeatStatus = "CheckOut"
		seatReservationDetails[i].Timestamp = userCheckOutTime
		seatReservationDetailsAsBytes, _ := json.Marshal(seatReservationDetails[i])
		stub.PutState(seatReservationDetailsIndexKey, seatReservationDetailsAsBytes)


		restSeatNo  := seatReservationDetails[i].RestSeatNo
		seatIndexName := "objectType~restSeatNo"
		key, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo})
		seatDetailsAsByte, _ := stub.GetState(key)
		_ = json.Unmarshal([]byte(seatDetailsAsByte), &seatDetails)
		seatDetails.SeatStatus = "Available"
		seatAsBytes, _ := json.Marshal(seatDetails)
		stub.PutState(key, seatAsBytes)
		i++
	}

	//SeatReservationDetial
	//seatReservationIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservation, seatNo})
	reservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeReservationDetails, reservationNo})
	reservationDetailsAsByte, err := stub.GetState(reservationDetailsIndexKey)
	err = json.Unmarshal([]byte(reservationDetailsAsByte), &reservationDetails)
	
	reservationDetails.UserCheckOutTime = userCheckOutTime
	reservationDetailsAsBytes, _ := json.Marshal(reservationDetails)
		
	stub.PutState(reservationDetailsIndexKey, reservationDetailsAsBytes)

	
	//seatReservationAsBytes, _  := stub.GetState(seatReservationIndexKey)
	return shim.Success(reservationDetailsAsBytes)
}

func (rtr *ReturntoRestaurantChaincode) SeatSanitizeStart(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	reservationNo := args[0]
	var jsonResp string
	var reservationDetails ReservationDetails
	//var userReservation	UserReservation
	var seatReservationDetails = []SeatReservationDetails{}
	indexName := "objectType~reservationNo"
	reservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeReservationDetails, reservationNo})
	reservationDetailsAsByte, _  := stub.GetState(reservationDetailsIndexKey)

	if err != nil {
		errstr := "Failed to get state for " + reservationNo + " : "+ err.Error()
		return shim.Error(errstr)
	} else if reservationDetailsAsByte == nil {
		jsonResp = "{\"Error\":\"Reservation does not exist: " + reservationNo + "\"}"
		return shim.Error(jsonResp)
	}
	err = json.Unmarshal([]byte(reservationDetailsAsByte), &reservationDetails)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of: " + reservationNo + "\"}"
		return shim.Error(jsonResp)
	}
	currentTime := time.Now()
	sanitizationStartTime := currentTime.Format("2006.01.02 15:04:05")
	reservationDetails.SanitizationStartTime = sanitizationStartTime
	reservationDetailsasBytes, err := json.Marshal(reservationDetails)
	
	stub.PutState(reservationDetailsIndexKey, reservationDetailsasBytes)
	seatDetIndexName := "objectType~reservationNo~restSeatNo"
	// seatReservationDetails, err := stub.GetState(seatReservationDetailsIndexKey)
	getSeatReservationDetails, _ := getDetailsFromQuery(stub, objectTypeSeatReservationDetails, "reservationNo", reservationNo)
   _ = json.Unmarshal([]byte(getSeatReservationDetails), &seatReservationDetails)
   
	// //seatNo := reservationDetails.SeatNo
	// seatReservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservationDetails, reservationNo})
	// seatReservationDetailsAsByte, err := stub.GetState(seatReservationDetailsIndexKey)
	// _ = json.Unmarshal([]byte(seatReservationDetailsAsByte), &seatReservationDetails)
	i := 0
	for i < len(seatReservationDetails) {
		seatReservationDetailsIndexKey, _ := stub.CreateCompositeKey(seatDetIndexName, []string{objectTypeSeatReservationDetails, reservationNo,seatReservationDetails[i].RestSeatNo})
		seatReservationDetails[i].ResrvSeatStatus = "Sanitzation Process Started"
		seatReservationDetails[i].Timestamp = sanitizationStartTime
		seatReservationDetailsAsBytes, _ := json.Marshal(seatReservationDetails[i])
		stub.PutState(seatReservationDetailsIndexKey, seatReservationDetailsAsBytes)
		
		restSeatNo  := seatReservationDetails[i].RestSeatNo
		seatIndexName := "objectType~restSeatNo"
		key, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo})
		seatDetailsAsByte, _ := stub.GetState(key)
		_ = json.Unmarshal([]byte(seatDetailsAsByte), &seatDetails)
		seatDetails.SeatStatus = "Sanitization Process"
		//seatNo := seatDetails.SeatNo
		//restaurantNo := seatDetails.RestaurantNo
		seatIndexName =  "objectType~restSeatNo"
		//seatIndexName = "objectType~restaurantNo~seatNo"
		//seatDetailskey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restaurantNo, strconv.Itoa(seatNo)})
		
		seatDetailskey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo})
		seatAsBytes, _ := json.Marshal(seatDetails)
		stub.PutState(seatDetailskey, seatAsBytes)
		i++
		
	}

	return shim.Success(reservationDetailsasBytes)

	// currentTime := time.Now()
	// sanitizationStartTime := currentTime.Format("2006.01.02 15:04:05")
	// //indexName = "objectType~seatNo"
	// //seatReservationDetailIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservationDetails, seatNo})
	// value := []byte{0x00}

	// //seatReservationDetail = SeatReservationDetail{objectTypeSeatReservationDetail, reservationNo, seatNo, "In Process", sanitizationStartTime, ""}
	
	
	// seatReservationasBytes, err := json.Marshal(seatReservationDetail)
	// if err != nil {
	// 	return shim.Error(err.Error())
	// }
	// stub.PutState(seatResrvIndexKey, seatReservationasBytes)
	// stub.PutState(seatReservationDetailIndexKey, value)
	// seatReservationAsBytes, _  := stub.GetState(seatResrvIndexKey)
	
}

func (rtr *ReturntoRestaurantChaincode) SeatSanitizeEnd(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	reservationNo := args[0]
	var seatReservationDetails = []SeatReservationDetails{}
	var reservationDetails ReservationDetails
	
	var jsonResp string
	indexName := "objectType~reservationNo"
	reservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeReservationDetails, reservationNo})
	reservationDetailsAsByte, _  := stub.GetState(reservationDetailsIndexKey)

	if err != nil {
		errstr := "Failed to get state for " + reservationNo + " : "+ err.Error()
		return shim.Error(errstr)
	} else if reservationDetailsAsByte == nil {
		jsonResp = "{\"Error\":\"Reservation does not exist: " + reservationNo + "\"}"
		return shim.Error(jsonResp)
	}
	err = json.Unmarshal([]byte(reservationDetailsAsByte), &reservationDetails)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of: " + reservationNo + "\"}"
		return shim.Error(jsonResp)
	}

	// seatResrvIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservationDetails, reservationNo})
	// seatReservationAsBytes, _  := stub.GetState(seatResrvIndexKey)

	// if err != nil {
	// 	errstr := "Failed to get state for " + reservationNo + " : "+ err.Error()
	// 	return shim.Error(errstr)
	// } else if seatReservationAsBytes == nil {
	// 	jsonResp = "{\"Error\":\"reservationNo does not exist: " + reservationNo + "\"}"
	// 	return shim.Error(jsonResp)
	// }
	// err = json.Unmarshal([]byte(seatReservationAsBytes), &seatReservationDetail)
	// if err != nil {
	// 	jsonResp = "{\"Error\":\"Failed to decode JSON of: " + reservationNo + "\"}"
	// 	return shim.Error(jsonResp)
	// }

	//seatNo := seatReservationDetail.SeatNo
	currentTime := time.Now()
	sanitizationEndTime := currentTime.Format("2006.01.02 15:04:05")
	reservationDetails.SanitizationEndTime = sanitizationEndTime
	reservationDetailsasBytes, err := json.Marshal(reservationDetails)
	
	stub.PutState(reservationDetailsIndexKey, reservationDetailsasBytes)
	
	// currentTime := time.Now()
	// sanitizationEndTime := currentTime.Format("2006-Jan-02 15:04:05")
	// err = json.Unmarshal([]byte(seatReservationAsBytes), &seatReservationDetail)
	// seatReservationDetail.ResrvSeatStatus = "Available"
	// seatReservationDetail.SanitizationEndTime = sanitizationEndTime
	
	// seatReservationDetailasBytes, _ := json.Marshal(seatReservationDetail)
	// err = stub.PutState(seatResrvIndexKey, seatReservationDetailasBytes) //rewrite the marble
	// if err != nil {
	// 	return shim.Error(err.Error())
	// }
	// seatReservationAsBytes, _  = stub.GetState(seatResrvIndexKey)
	seatDetIndexName := "objectType~reservationNo~restSeatNo"
	// seatReservationDetails, err := stub.GetState(seatReservationDetailsIndexKey)
	getSeatReservationDetails, _ := getDetailsFromQuery(stub, objectTypeSeatReservationDetails, "reservationNo", reservationNo)
   _ = json.Unmarshal([]byte(getSeatReservationDetails), &seatReservationDetails)

	// seatReservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservationDetails, reservationNo})
	// seatReservationDetailsAsByte, err := stub.GetState(seatReservationDetailsIndexKey)
	// _ = json.Unmarshal([]byte(seatReservationDetailsAsByte), &seatReservationDetails)
	i := 0
	for i < len(seatReservationDetails){
	seatReservationDetailsIndexKey, _ := stub.CreateCompositeKey(seatDetIndexName, []string{objectTypeSeatReservationDetails, reservationNo,seatReservationDetails[i].RestSeatNo})
	seatReservationDetails[i].ResrvSeatStatus = "Sanitzation Process End, Now it is available to use"
	seatReservationDetails[i].Timestamp = sanitizationEndTime
	seatReservationDetailsAsBytes, _ := json.Marshal(seatReservationDetails[i])
	stub.PutState(seatReservationDetailsIndexKey, seatReservationDetailsAsBytes)
	
	restSeatNo  := seatReservationDetails[i].RestSeatNo
	seatIndexName := "objectType~restSeatNo"
	key, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo})
	seatDetailsAsByte, _ := stub.GetState(key)
	_ = json.Unmarshal([]byte(seatDetailsAsByte), &seatDetails)
	seatDetails.SeatStatus = "Seated"
	// seatNo := seatDetails.SeatNo
	// restaurantNo := seatDetails.RestaurantNo
	seatIndexName =  "objectType~restSeatNo"
	//seatIndexName = "objectType~restaurantNo~seatNo"
	//seatDetailskey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restaurantNo, strconv.Itoa(seatNo)})
	seatDetailskey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo})
	seatAsBytes, _ := json.Marshal(seatDetails)
	stub.PutState(seatDetailskey, seatAsBytes)
	i++
	}

	return shim.Success([]byte("done"))
}



func ConfirmReservation(stub shim.ChaincodeStubInterface, restSeatNo []string, userID string, reservationNo string, restaurantNo string) ([]byte, string) {
	intreservationNo, _ := strconv.Atoi(reservationNo)
	userReservation := &UserReservation{objectUserReservation, userID, intreservationNo, "Reservation Confirmed", restaurantNo}
	userReservationasBytes, err := json.Marshal(userReservation)
	if err != nil {
		return nil, err.Error()
	} 	
	indexName := "objectType~reservationNo"
	userResrvIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectUserReservation , reservationNo})
	
	err = stub.PutState(userResrvIndexKey, userReservationasBytes)
	if err != nil {
		return nil, err.Error()
	}
	
	
//	userReservationasBytes, _  = stub.GetState(userResrvIndexKey)
	return userReservationasBytes, ""

}

func SeatConfirmation(stub shim.ChaincodeStubInterface, reservationNo string, restSeatNo []string) ([]byte, string) {
	//seatReservation := &SeatReservationDetails{objectTypeSeatReservationDetails, reservationNo, seatNo, userBodyTemp, userCheckInTime, ""}
	// currentTime := time.Now()
	// ReservationTime := currentTime.Format("2006-Jan-02 15:04:05")
	// seatReservation := &SeatReservationDetails{objectTypeSeatReservationDetails, reservationNo, restSeatNo, "Booked", ReservationTime }
	// seatReservationasBytes, err := json.Marshal(seatReservation)
	// if err != nil {
	// 	return nil, err.Error()
	// }
	// indexName := "objectType~reservationNo"
	// userResrvIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservationDetails, reservationNo})
	
	// // seatindexName := "objectType~restSeatNo"
	// // seatReservationIndexKey, err := stub.CreateCompositeKey(seatindexName, []string{objectTypeSeatReservationDetails, restSeatNo})
	// // value := []byte{0x00}
	// if err != nil {

	// 	return nil, err.Error()
	// }

	if len(restSeatNo) != 0{
		i := 0
		for i < len(restSeatNo){
			currentTime := time.Now()
			timestamp := currentTime.Format("2006-Jan-02 15:04:05")
			seatReservationDetails := &SeatReservationDetails{objectTypeSeatReservationDetails, reservationNo, restSeatNo[i], "Booked", timestamp}
			seatReservationDetailsasBytes, err := json.Marshal(seatReservationDetails)
			if err != nil {
				return nil, err.Error()
			} 
			indexName := "objectType~reservationNo~restSeatNo"
			seatReservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservationDetails, reservationNo, restSeatNo[i]})
			if err != nil {
				return nil, err.Error()
			}
			fmt.Println(string(seatReservationDetailsasBytes))
			stub.PutState(seatReservationDetailsIndexKey, seatReservationDetailsasBytes)
			
			seatIndexName := "objectType~restSeatNo"
			key, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo[i]})
			seatDetailsAsByte, err := stub.GetState(key)
			_ = json.Unmarshal([]byte(seatDetailsAsByte), &seatDetails)
			seatDetails.SeatStatus = "Seat Booked, Sanitization Pending"
			// seatNo := seatDetails.SeatNo
			// restaurantNo := seatDetails.RestaurantNo
			seatIndexName =  "objectType~restSeatNo"
			//seatIndexName = "objectType~restaurantNo~seatNo"
			//seatDetailskey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restaurantNo, strconv.Itoa(seatNo)})
			seatDetailskey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo[i]})
			seatAsBytes, _ := json.Marshal(seatDetails)
			stub.PutState(seatDetailskey, seatAsBytes)
			


			//stub.PutState(userResrvIndexKey, seatReservationasBytes)
			//stub.PutState(seatReservationIndexKey, value)

			
			i++
			//return reservationAsBytes, ""
		}
		indexName := "objectType~reservationNo"
		resrvDetailsIndexKey, _ := stub.CreateCompositeKey(indexName, []string{objectTypeReservationDetails, reservationNo})
		reservationDetails := &ReservationDetails{ObjectType: objectTypeReservationDetails, ReservationNo: reservationNo}
		reservationAsBytes, _ := json.Marshal(reservationDetails)
		stub.PutState(resrvDetailsIndexKey, reservationAsBytes)
		return reservationAsBytes ,""
	}
	return nil, "Please select the seat"
}



func checkForAvailableSeat(stub shim.ChaincodeStubInterface, restaurantNo string) ([]byte, string) {
	
	var restaurantJSON Restaurant
	var seatDetailsArray = []SeatDetails{}
	var jsonResp string
	indexName := "objectType~restaurantNo"
	restaurantIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeRestaurant, restaurantNo})
	
	resAsBytes, err := stub.GetState(restaurantIndexKey)
	fmt.Println(stub.GetTxID())
	if err != nil {
		errstr := "Failed to get state for " + restaurantNo + " : "+ err.Error()
		return nil, errstr
	} else if resAsBytes == nil {
		jsonResp = "{\"Error\":\"Restaurant does not exist: " + restaurantNo + "\"}"
		return nil, jsonResp
	}
	err = json.Unmarshal([]byte(resAsBytes), &restaurantJSON)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of: " + restaurantNo + "\"}"
		return nil, jsonResp
	}

	//seatCapacity, err := strconv.Atoi(restaurantJSON.RestaurantSeatCapacity)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to Convert seat number to integer: " + err.Error() + "\"}"
		return nil, jsonResp
	}

	//seatIndexName := "objectType~restaurantNo~seatNo"
	buffer, _ := getDetailsFromQuery(stub, objectTypeSeatDetails,  "restaurantNo", restaurantNo )
	//fmt.Println(buffer)
	// stringBuffer :=  string(buffer)
	json.Unmarshal(buffer, &seatDetailsArray)
	//fmt.Println(stringBuffer)
	
	
	// seatIndexName :=  "objectType~restSeatNo"

	// var seatJSON SeatDetails
	i := 0
	for i < len(seatDetailsArray){
		seatStatus := seatDetailsArray[i].SeatStatus
	//	fmt.Println(seatDetailsArray[i])
		if seatStatus == "Available" {
			seatAsBytes, _  := json.Marshal(seatDetailsArray[i])
			return seatAsBytes, ""
		}
		fmt.Println(len(seatDetailsArray))
		//fmt.Println(i)
		i = i + 1
	}

	// for i <= seatCapacity {
	// 	//seatIndexKey, err := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restaurantJSON.RestaurantNo, strconv.Itoa(i)})
		
	// 	seatIndexKey, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restSeatNo})
	// 	seatAsBytes, err := stub.GetState(seatIndexKey)
	// 	if err != nil {
	// 		err := "Error in creating key =" + err.Error()
	// 		return nil, err
	// 	}
	// 	err = json.Unmarshal([]byte(seatAsBytes), &seatJSON)
	// 	seatStatus := seatJSON.SeatStatus
	// 	if seatStatus == "Available" {
	// 		return seatAsBytes, ""
	// 	}
	// 	fmt.Println(seatCapacity)
	// 	fmt.Println(i)
	// 	i += i
	
	// }

	// // for i <= seatCapacity {
	// // 	//qryKey, errkey := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatReservationDetail, strconv.Itoa(i)})
	// // 	if errkey != nil {
	// // 		err := "Error in creating key =" + errkey.Error()
	// // 		return nil, err
	// // 	}

	// // 	fmt.Printf("Composite Key=%s\n", qryKey)

	// // 	seatAsBytes, _  := stub.GetState(qryKey)
	// // 	err = json.Unmarshal([]byte(seatAsBytes), &seatJSON)
	// // 	seatStatus := seatJSON.ResrvSeatStatus
	// // 	if seatStatus == "Available" {
	// // 		return seatAsBytes, ""
	// // 	}
	// // }
	return nil, "no seat Available"
}


func (rtr *ReturntoRestaurantChaincode) giveFeedbackByReservationNo(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	reservationNo := args[0]
	q1 := args[1]
	q2 := args[2]
	q3 := args[3]
	q4 := args[4]
	q5 := args[5]
	restaurantPreference, _ := strconv.Atoi(args[6])
	
	var userReservation UserReservation
	indexName := "objectType~reservationNo"
	

	userResrvIndexKey, _ := stub.CreateCompositeKey(indexName, []string{objectUserReservation , reservationNo})
	userReservationAsByte, _ := stub.GetState(userResrvIndexKey)
	json.Unmarshal([]byte(userReservationAsByte), &userReservation)

	restaurantNo := userReservation.RestaurantNo

	userRestaurantFeedback := &UserRestaurantFeedback{objectTypeUserRestaurantFeedback, restaurantNo, reservationNo, q1, q2, q3, q4, q5, restaurantPreference}
	userRestaurantFeedbackIndexKey, _ := stub.CreateCompositeKey(indexName, []string{objectTypeUserRestaurantFeedback , reservationNo})
	userRestaurantFeedbackAsByte, _ := json.Marshal(userRestaurantFeedback)
	stub.PutState(userRestaurantFeedbackIndexKey, userRestaurantFeedbackAsByte)
	fmt.Println("Feedback Submitted ")

	return shim.Success([]byte("Feedback Submitted"))

}

func (rtr *ReturntoRestaurantChaincode) getRestaurantRatingByRestaurantNo(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	restaurantNo := args[0]
	buffer := getRestRatingByNo(stub, restaurantNo)
	return shim.Success(buffer.Bytes())
}

func getRestRatingByNo(stub shim.ChaincodeStubInterface, restaurantNo string) ( *bytes.Buffer) {
	var userRestaurantFeedback = []UserRestaurantFeedback{}
	var buffer bytes.Buffer

	restaurantFeedback, _ := getDetailsFromQuery(stub, objectTypeUserRestaurantFeedback,  "restaurantNo", restaurantNo )
	json.Unmarshal(restaurantFeedback, &userRestaurantFeedback)

	totalCount := 0
	totalQ1 := 0
	totalQ2 := 0
	totalQ3 := 0
	totalQ4 := 0
	totalQ5 := 0
	sumRestPref := 0
	totalRestPref := 0
	i := 0
	for i < len(userRestaurantFeedback) {
		fmt.Println(userRestaurantFeedback[i])
		q1 := userRestaurantFeedback[i].Q1
		q2 := userRestaurantFeedback[i].Q2
		q3 := userRestaurantFeedback[i].Q3
		q4 := userRestaurantFeedback[i].Q4
		q5 := userRestaurantFeedback[i].Q5
		fmt.Println(q1)
		fmt.Println(q2)
		restaurantPreference := userRestaurantFeedback[i].RestaurantPreference
		if q1 == "true"{
			totalQ1 += 1
		}
		if q2 == "true"{
			totalQ2++
		}
		if q3 == "true"{
			totalQ3++
		}
		if q4 == "true"{
			totalQ4++
		}
		if q5 == "true"{
			totalQ5++
		}
		if restaurantPreference != 0 {
			sumRestPref = sumRestPref + restaurantPreference
			totalRestPref++
		}

		i++
		totalCount++
		fmt.Println(totalCount)
	}
	averageRestPref := int(sumRestPref/totalRestPref)
	
	// fmt.Println(strconv.Itoa(sumRestPref))
	
	// fmt.Println(strconv.Itoa(totalRestPref))
	// //strconv.FormatInt(averageRestPref,10)
	// fmt.Printf(restaurantFeedback)

	fmt.Println(strconv.Itoa(totalQ1))
	buffer.WriteString("{\"q1\":\"")
	buffer.WriteString(strconv.Itoa(totalQ1))
	buffer.WriteString("\",")
	buffer.WriteString("\"q2\":\"")
	buffer.WriteString(strconv.Itoa(totalQ2))
	buffer.WriteString("\",")
	buffer.WriteString("\"q3\":\"")
	buffer.WriteString(strconv.Itoa(totalQ3))
	buffer.WriteString("\",")
	buffer.WriteString("\"q4\":\"")
	buffer.WriteString(strconv.Itoa(totalQ4))
	buffer.WriteString("\",")
	buffer.WriteString("\"q5\":\"")
	buffer.WriteString(strconv.Itoa(totalQ5))
	buffer.WriteString("\",")
	buffer.WriteString("\"Outof\":\"")
	buffer.WriteString(strconv.Itoa(totalCount))
	buffer.WriteString("\",")

	buffer.WriteString("\"averagePref\": {")
	buffer.WriteString("\"averageRestPref\":\"")
	buffer.WriteString(strconv.Itoa(averageRestPref))
	buffer.WriteString("\",")
	buffer.WriteString("\"outRestPref\":\"")
	buffer.WriteString(strconv.Itoa(totalRestPref))
	buffer.WriteString("\"}")

	buffer.WriteString("}")

	return &buffer	

}

