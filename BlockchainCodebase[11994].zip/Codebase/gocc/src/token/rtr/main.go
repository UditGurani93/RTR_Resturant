package main

import (
   "fmt"
	"bytes"
   // The shim package
   "github.com/hyperledger/fabric/core/chaincode/shim"

   // peer.Response is in the peer package
   "github.com/hyperledger/fabric/protos/peer"

   // Conversion functions
   "strconv"
   //"github.com/hyperledger/fabric/protos/ledger/queryresult"

   // JSON Encoding
   "encoding/json"
)

// RestaurantChaincode Represents our chaincode object
type ReturntoRestaurantChaincode struct {
}

// OwnerPrefix is used for creating the key for balances
const   OwnerPrefix="owner."
const 	RestaurantObjectType = "RestaurantObjectType"
const 	UserObjectType = "User"
const	ResIndexName = "restaurantName~restaurantNo"
const	UserIndexName = "userName~userID"
const 	objectTypeRestaurant = "Restaurant"
const	objectTypeSeatDetails = "SeatDetails"

// Init Implements the Init method
func (rtr *ReturntoRestaurantChaincode) InitRestaurant(stub shim.ChaincodeStubInterface) peer.Response {

   // Simply print a message
   var seatDetail SeatDetails 
	
	restaurant := []Restaurant{
		Restaurant{ObjectType: RestaurantObjectType, RestaurantName: "Chipotle Mexican Grill", RestaurantLocation: "718 Ponce De Leon Ave NE, Atlanta, GA 30306, United States", RestaurantGoogleLocation: "33.774670, -84.365466", RestaurantThermalScannerEnabled: "YES", RestaurantSeatCapacity: "45", RestaurantBranch: "Chipotle", RestaurantCCTVEnabled: "Yes"},
		Restaurant{ObjectType: RestaurantObjectType, RestaurantName: "Murphy's Mountain Grill", RestaurantLocation: "27906 CO-74, Evergreen, CO 80439, United States", RestaurantGoogleLocation: "33.814538, -84.351390", RestaurantThermalScannerEnabled: "Yes", RestaurantSeatCapacity: "30", RestaurantBranch: "Murphy's", RestaurantCCTVEnabled: "Yes"},
		Restaurant{ObjectType: RestaurantObjectType, RestaurantName: "Rio Grande", RestaurantLocation: "4609 Jonesboro Rd, Forest Park 30297", RestaurantGoogleLocation: "33.648721, -84.381228", RestaurantThermalScannerEnabled: "Yes", RestaurantSeatCapacity: "35", RestaurantBranch: "RioGrande", RestaurantCCTVEnabled: "Yes"},
		Restaurant{ObjectType: RestaurantObjectType, RestaurantName: "Metropolitan at The 9, Autograph Collection",RestaurantLocation : "2017 E. 9th Street, Cleveland, Ohio",RestaurantGoogleLocation : "41.499944, -81.685856",RestaurantThermalScannerEnabled : "Yes",RestaurantSeatCapacity : "45",RestaurantBranch : "Metropolitan at The 9",RestaurantCCTVEnabled : "Yes"},	
		Restaurant{ObjectType: RestaurantObjectType, RestaurantName : "Firehouse Subs",RestaurantLocation : "1393 GA Highway 40 East Kingsland, GA 31548",RestaurantGoogleLocation : "30.788195, -81.652371",RestaurantThermalScannerEnabled : "Yes",RestaurantSeatCapacity : "45",RestaurantBranch : "Firehouse Subs",RestaurantCCTVEnabled : "Yes"},
		Restaurant{ObjectType: RestaurantObjectType, RestaurantName : "Leo's Pizzaria",RestaurantLocation : "2220 Southwestern Blvd, West Seneca, NY 14224, United States",RestaurantGoogleLocation : "42.854838, -78.744252",RestaurantThermalScannerEnabled : "No",RestaurantSeatCapacity : "40",RestaurantBranch : "Leo's Pizzaria",RestaurantCCTVEnabled : "Yes"},
		Restaurant{ObjectType: RestaurantObjectType, RestaurantName : "Teds montana grill",RestaurantLocation : "Downtown 133 Luckie Street Atlanta, GA 30303",RestaurantGoogleLocation : "33.758778, -84.390608",RestaurantThermalScannerEnabled : "Yes",RestaurantSeatCapacity : "40",RestaurantBranch : "Teds montana grill",RestaurantCCTVEnabled : "Yes"},
	}

	i := 0
	k := 0
	resSeatCapacity := 0
	for i < len(restaurant) {
		fmt.Println("i is ", i)
		//restuarant
		restaurant[i].RestaurantNo = "RES" + strconv.Itoa(i)
		resAsBytes, _ := json.Marshal(restaurant[i])
		indexName := "objectType~restaurantNo"
		key, err := stub.CreateCompositeKey(indexName, []string{objectTypeRestaurant, restaurant[i].RestaurantNo})
		stub.PutState( key , resAsBytes)
		ResNameNoIndexKey, err := stub.CreateCompositeKey(ResIndexName, []string{restaurant[i].RestaurantName, restaurant[i].RestaurantNo})
		if err != nil {
			return shim.Error(err.Error())
		}
		//  Save index entry to state. Only the key name is needed, no need to store a duplicate copy of the marble.
		//  Note - passing a 'nil' value will effectively delete the key from state, therefore we pass null character as value
		value := []byte{0x00}
		stub.PutState(ResNameNoIndexKey, value)
		fmt.Println("Added", restaurant[i])
		k = 1
		seatIndexName := "objectType~restaurantNo~seatNo"
		seatRestNoIndexName := "objectType~restSeatNo"
		resSeatCapacity, _ = strconv.Atoi(restaurant[i].RestaurantSeatCapacity)
		for k <= resSeatCapacity {
			seatDetail = SeatDetails{ObjectType: objectTypeSeatDetails, RestaurantNo: restaurant[i].RestaurantNo, SeatStatus: "Available"}			
			seatDetail.SeatNo = k
			restSeatNo := restaurant[i].RestaurantName[0:4]
			restSeatNo = restSeatNo +""+ strconv.Itoa(k)
			seatDetail.RestSeatNo = restSeatNo
			seatAsBytes, _ := json.Marshal(seatDetail)
			
			fmt.Println("Added",seatDetail)
			key, _ := stub.CreateCompositeKey(seatIndexName, []string{objectTypeSeatDetails, restaurant[i].RestaurantNo, strconv.Itoa(seatDetail.SeatNo)})
			err := stub.PutState( key , value)
			if err != nil {
				return shim.Error(err.Error())
			}
			
			key1, _ := stub.CreateCompositeKey(seatRestNoIndexName, []string{objectTypeSeatDetails, restSeatNo})
			_ = stub.PutState( key1 , seatAsBytes)
			k = k + 1
		}

		i = i + 1
	}

	

   return shim.Success(nil)
}

func (rtr *ReturntoRestaurantChaincode) InitUser(stub shim.ChaincodeStubInterface) peer.Response {
	user := []User{
		User{ObjectType: UserObjectType, UserName: "Anuj Negi" ,MemberShip: "Prime" },
		User{ObjectType: UserObjectType, UserName: "Mallik" ,MemberShip: "Prime" },
		User{ObjectType: UserObjectType, UserName: "Preeti" ,MemberShip: "Normal" },
		User{ObjectType: UserObjectType, UserName: "Rachin" ,MemberShip: "Normal" },
		User{ObjectType: UserObjectType, UserName: "Mridul" ,MemberShip: "Normal" },
		User{ObjectType: UserObjectType, UserName: "Neeraj" ,MemberShip: "Normal" },
		User{ObjectType: UserObjectType, UserName: "Rohit" ,MemberShip: "Prime" },
		User{ObjectType: UserObjectType, UserName: "Manish" ,MemberShip: "Prime" },
		User{ObjectType: UserObjectType, UserName: "Priya" ,MemberShip: "Normal" },
	}
	//User

	i := 0
	for i < len(user) {
		fmt.Println("i is ", i)
		user[i].UserID = "USER" + strconv.Itoa(i)
		userAsBytes, _ := json.Marshal(user[i])
		indexName := "objectType~userID"

		key, err := stub.CreateCompositeKey(indexName, []string{UserObjectType, user[i].UserID})
		
		stub.PutState( key , userAsBytes)
		UserNameIdIndexKey, err := stub.CreateCompositeKey(UserIndexName, []string{user[i].UserName, user[i].UserID})
		if err != nil {
			return shim.Error(err.Error())
		}
		//  Save index entry to state. Only the key name is needed, no need to store a duplicate copy of the marble.
		//  Note - passing a 'nil' value will effectively delete the key from state, therefore we pass null character as value
		value := []byte{0x00}
		stub.PutState(UserNameIdIndexKey, value)
		
		fmt.Println("Added User", user[i])
		i = i + 1
	}
	return shim.Success(nil)
}


func (rtr *ReturntoRestaurantChaincode) Init(stub shim.ChaincodeStubInterface) peer.Response {
	return shim.Success(nil)
}
// Invoke method
func (rtr *ReturntoRestaurantChaincode) Invoke(stub shim.ChaincodeStubInterface) peer.Response {

   // Get the function name and parameters
   function, args := stub.GetFunctionAndParameters()

   fmt.Println("Invoke executed : ", function, " args=", args)

   switch {

   // Query function
	case	function == "InitUser":
		return rtr.InitUser(stub)
	case	function == "InitRestaurant":
		return rtr.InitRestaurant(stub)
	case	function == "FindAvailableSeat":
		return rtr.FindAvailableSeat(stub, args)
   	case	function == "SeatReservation":		  
   		return rtr.SeatReservation (stub, args)
	case	function == "UserCheckIn":		  
   		return rtr.UserCheckIn (stub, args)
	case	function == "UserCheckOut":		  
   		return rtr.UserCheckOut (stub, args)
	case	function == "SeatSanitizeStart":		  
		return rtr.SeatSanitizeStart (stub, args)
	case	function == "SeatSanitizeEnd":
		return rtr.SeatSanitizeEnd(stub, args)
	case	function == "queryAllUser":
		return rtr.queryAllUser(stub)
	case	function == "queryEntityByPartialKey":
		return rtr.queryEntityByPartialKey(stub,args)
	case	function == "QueryAllReservationByUsedID":
		return rtr.QueryAllReservationByUsedID(stub,args)
	case	function == "QueryByFieldValue":
		return rtr.QueryByFieldValue(stub,args)
	case	function == "GetReservationDeatilsByResvNo":
		return rtr.GetReservationDeatilsByResvNo(stub,args)
	case	function == "GetHistoryOfSeatBySeatNo":
		return rtr.GetHistoryOfSeatBySeatNo(stub,args)
	case	function == "GetRestaurantsListWithDetails":
		return rtr.GetRestaurantsListWithDetails(stub)
	case	function == "GetAllCustomerByRestaurantID":
		return rtr.GetAllCustomerByRestaurantID(stub, args)
	case	function == "UploadCertificationByRestaurantNo":
		return rtr.UploadCertificationByRestaurantNo(stub, args)
	case	function == "InitRestaurantOffer":
		return rtr.InitRestaurantOffer(stub)
	case	function == "GetAllOffersByUserIDRestaurantNo":
		return rtr.GetAllOffersByUserIDRestaurantNo(stub, args)
	case	function == "GetHistoryOfReservationByReservationNo":
		return rtr.GetHistoryOfReservationByReservationNo(stub, args)
	case	function == "GetRestaurantSeatStatusbyRestaurantNo":
		return rtr.GetRestaurantSeatStatusbyRestaurantNo(stub, args)
	case	function == "giveFeedbackByReservationNo":
		return rtr.giveFeedbackByReservationNo(stub, args)
	case	function == "getRestaurantRatingByRestaurantNo":
		return rtr.getRestaurantRatingByRestaurantNo(stub, args)
   }
   
   return shim.Error("Invalid function")
}



func (rtr *ReturntoRestaurantChaincode) queryAllUser(stub shim.ChaincodeStubInterface) peer.Response {

	startKey := "User~USER0"
	endKey := "User~USER999"
//	QryIterator, err := stub.GetStateByPartialCompositeKey(objectType, args)
	
	resultsIterator, err := stub.GetStateByRange(startKey, endKey)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryResults
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- queryAllCars:\n%s\n", buffer.String())

	return shim.Success(buffer.Bytes())
}

func (rtr *ReturntoRestaurantChaincode) queryEntityByPartialKey(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	// Print statements used in dev mode
	fmt.Printf("==== Exec qry with:  ")
	fmt.Println(args)
	var indexName = ""
	
	if args[0] == "Restaurant" {
		indexName = "objectType~restaurantNo"
	} else if args[0] == "User"{
		indexName = "objectType~userID"
	} else if args[0] == "SeatDetails" {
		//indexName = "objectType~restaurantNo~seatNo"
		indexName = "objectType~restSeatNo"		
	}
	// Gets the state by partial query key

	entityAsByte, err, _ := getEntityDetailsByDocName(stub, indexName, args )
	if err != nil {
		fmt.Printf("Error in getting by range=" + err.Error())
		return shim.Error(err.Error())
	}
	// QryIterator, err := stub.GetStateByPartialCompositeKey(indexName, args)
	// if err != nil {
	// 	fmt.Printf("Error in getting by range=" + err.Error())
	// 	return shim.Error(err.Error())
	// }
	// var resultJSON = "["
	// counter := 0
	// var userAsBytes []byte
	// // Iterate to read the keys returned
	// for QryIterator.HasNext() {
	// 	// Hold pointer to the query result
	// //	var resultKV *queryresult.KV
	// 	var err error

	// 	// Get the next element
	// 	resultKV, err := QryIterator.Next()
	// 	if err != nil {
	// 		fmt.Println("Err=" + err.Error())
	// 		return shim.Error(err.Error())
	// 	}

	// 	// Split the composite key and send it as part of the result set
	// 	_, arr, _ := stub.SplitCompositeKey(resultKV.GetKey())
	// 	fmt.Println(arr)
	// 	key1, err := stub.CreateCompositeKey(indexName, arr)
		
	// 	userAsBytes, _ = stub.GetState(key1)
	// 	resultJSON += " [" + string(userAsBytes) + "] "
	// 	counter++

	// }
	// // Closing
	// QryIterator.Close()

	// resultJSON += "]"
	// resultJSON = "Counter=" + strconv.Itoa(counter) + "  " + resultJSON
	// fmt.Println("Done.")
	 return shim.Success(entityAsByte)
}

// Chaincode registers with the Shim on startup
func main() {
	fmt.Printf("Started Chaincode. token/cid\n")
	err := shim.Start(new(ReturntoRestaurantChaincode))
	if err != nil {
		fmt.Printf("Error starting chaincode: %s", err)
	}
}