package main

// Restaurant structure manages the state 

// "objectType~restaurantNo"
type Restaurant struct {
	ObjectType 								string	 `json:"objectType"` 
	RestaurantNo   							string   `json:"restaurantNo"`
	RestaurantName  						string   `json:"restaurantName"`
	RestaurantLocation						string   `json:"restaurantLocation"`
	RestaurantGoogleLocation				string   `json:"restaurantGoogleLocation"`
	RestaurantThermalScannerEnabled			string   `json:"restaurantThermalScanner"`			
	RestaurantSeatCapacity					string   `json:"restaurantSeatCapacity	"`
	RestaurantBranch						string   `json:"restaurantBranch"`
	RestaurantCCTVEnabled					string   `json:"restaurantCCTVEnabled"`
}

type RestaurantCertification struct {
	ObjectType 							string 	`json:"objectType"` 
	RestaurantNo   						string 	`json:"restaurantNo"`
	//Certification						string 	`json:"certification"`
}

type RestaurantOffers struct{
	ObjectType 							string 		`json:"objectType"`
	OfferNo								int			`json:"offerNo"`
	RestaurantNo						string		`json:"restaurantNo"`
	PromoCode							string		`json:"promoCode"`
	OfferDecription						string		`json:"offerDecription"`
	DiscountPercentage					string		`json:"discountPercentage"`
	DiscountUpto						string		`json:"discountUpto"`
	OfferValidityStartDate				string		`json:"offerValidityStartDate"`
	OfferValidityEndDate				string		`json:"offerValidityEndDate"`
	// valid for 1 means for all the user , 2 means for specific user checkout count , 3 for valid for prime and specific user checkout count , 4 means only for prime
	ValidFor							int 		`json:"validFor"`
	UserReservationCount				string		`json:"userReservationCount"`
}





