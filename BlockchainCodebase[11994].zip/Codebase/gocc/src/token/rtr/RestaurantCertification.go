// fs.readFileSync(‘./image.jpg’).toString(‘base64’)
package main

import (
//     "bufio"
//     "encoding/base64"
    "fmt"
//     "io/ioutil"
//     "os"
//        // JSON Encoding
 "encoding/json"
     // The shim package
   "github.com/hyperledger/fabric/core/chaincode/shim"

   // peer.Response is in the peer package
   "github.com/hyperledger/fabric/protos/peer"
)

const ObjectTypeNCRRestCert = "NCRRestaurantCertification"

func (rtr *ReturntoRestaurantChaincode) UploadCertificationByRestaurantNo(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
    restaurantNo := args[0]
    var verificationStatus string
    var certNCRRestaurantCertification NCRRestaurantCertification

    // localAuthorityStanderdCertificate, _ := os.Open("./download.jpg")
    // fdaCertificate, _ := os.Open("./download.jpg")
    // thermalScannerCertificate, _ := os.Open("./download.jpg")

    // localAuthorityEncoded := getCertificateEncoder(localAuthorityStanderdCertificate)
    // fdaEncoded := getCertificateEncoder(fdaCertificate)
    // thermalScannerEncoded := getCertificateEncoder(thermalScannerCertificate)

    localAuthorityEncoded := `./`+restaurantNo +`localAuthority.jpg`
    fdaEncoded := `./`+restaurantNo +`fda.jpg`
    thermalScannerEncoded := `./`+ restaurantNo+`thermalScanner.jpg`

     if ( localAuthorityEncoded != "" && fdaEncoded != "" && thermalScannerEncoded != ""){
        verificationStatus = "Verififed"
    } else {
        verificationStatus = "Not Verififed"
    }
    certNCRRestaurantCertification = NCRRestaurantCertification{ObjectType: ObjectTypeNCRRestCert, RestaurantNo: restaurantNo ,LocalAuthorityStanderdCertificate: localAuthorityEncoded,  FDACertificate: fdaEncoded , ThermalScannerCertificate: thermalScannerEncoded , VerificationStatus : verificationStatus }
    indexName := "objectType~restaurantNo"
    restCertAsBytes, _ := json.Marshal(certNCRRestaurantCertification)
		
    key, err := stub.CreateCompositeKey(indexName, []string{ObjectTypeNCRRestCert, restaurantNo})
    if err != nil {
        return shim.Error(err.Error())
    }	
    fmt.Println(string(restCertAsBytes))
    stub.PutState( key , restCertAsBytes)
	return shim.Success(nil)
}

// func getCertificateEncoder(f *os.File) (string) {
//     // Read entire JPG into byte slice.
//     reader := bufio.NewReader(f)
//     content, _ := ioutil.ReadAll(reader)

//     // Encode as base64.
//     encoded := base64.StdEncoding.EncodeToString(content)
//     return encoded


// }
