package main

type NCRRestaurantCertification struct {
	ObjectType 								string	 `json:"objectType"` 
	//VerificationNo							string 	`json:"verificationNo"`
	RestaurantNo  	 						string 	`json:"restaurantNo"`
	LocalAuthorityStanderdCertificate		string  `json:"localAuthorityStanderdCertificate"`
	FDACertificate							string	`json:"fdaCertificate"`
	ThermalScannerCertificate				string	`json:"thermalScannerCertificate"`
	VerificationStatus						string	`json:"verificationStatus"`	
}
