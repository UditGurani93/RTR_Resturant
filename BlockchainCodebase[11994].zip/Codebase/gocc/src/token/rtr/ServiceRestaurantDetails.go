package main

import (
   "fmt"

   "bytes"
   // The shim package
   "github.com/hyperledger/fabric/core/chaincode/shim"

   // peer.Response is in the peer package
   "github.com/hyperledger/fabric/protos/peer"

   // Conversion functions
   "strconv"

  // "time"

   // JSON Encoding
   "encoding/json"
)


func (rtr *ReturntoRestaurantChaincode) GetRestaurantsListWithDetails(stub shim.ChaincodeStubInterface ) peer.Response{
	var restaurant = []Restaurant{}
	var seatDetailsArray = []SeatDetails{}
	var buffer bytes.Buffer
	buffer.WriteString("[")
	indexName := "objectType~restaurantNo"
	restAsByte, err, _ := getEntityDetailsByDocName(stub, indexName, []string{objectTypeRestaurant} )
	if err != nil {
		return shim.Error(err.Error())
	}
	
	json.Unmarshal(restAsByte, &restaurant)
	fmt.Printf(string(restAsByte))
	i := 0
	for i < len(restaurant) {
		restaurantNo := restaurant[i].RestaurantNo
		//fmt.Println(i)
		seatDetails, err := getDetailsFromQuery(stub, objectTypeSeatDetails, "restaurantNo", restaurantNo)
		if err != "" {			
			return shim.Error(err)
		}
		json.Unmarshal(seatDetails, &seatDetailsArray)
		j := 0
		availableSeat := 0
		for j < len(seatDetailsArray){
			seatStatus := seatDetailsArray[j].SeatStatus
			if seatStatus == "Available" {
				availableSeat++		
				//fmt.Println("available seat :"+strconv.Itoa(availableSeat))		
			}
			j = j + 1
		//	fmt.Println("j  :"+strconv.Itoa(j))
		}
		restCertIndexKey, _ := stub.CreateCompositeKey(indexName, []string{ObjectTypeNCRRestCert, restaurantNo})
		certificateAsByte, _  := stub.GetState(restCertIndexKey)
	
		offerDetails, err := getDetailsFromQuery(stub, objectTypeRestaurantOffers, "restaurantNo", restaurantNo)
		if err != "" {			
			return shim.Error(err)
		}

		restAsBytes, _ := json.Marshal(restaurant[i])
		if i > 0{
			buffer.WriteString(",")
		}
		buffer.WriteString("[")
		buffer.WriteString(string(restAsBytes))
		//buffer.WriteString(string(restaurant[i]))
		fmt.Println(restaurant[i])
		buffer.WriteString(", { \"AvailableSeatCount\" :")
		buffer.WriteString(strconv.Itoa(availableSeat))
		buffer.WriteString("},")
		buffer.WriteString(string(certificateAsByte))
		buffer.WriteString(",")
		buffer.WriteString(string(offerDetails))
		buffer.WriteString("]")
		i = i + 1
	}
	fmt.Printf("- reservationDetails seatDetails:\n%s\n", buffer.String())
	buffer.WriteString("]")
	return shim.Success(buffer.Bytes())

}



func (rtr *ReturntoRestaurantChaincode) GetAllCustomerByRestaurantID(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	var userReservation = []UserReservation{}
	restaurantNo := args[0]
	var buffer bytes.Buffer
	buffer.WriteString("[")
	stringQry := `{
		"selector": {
		   "objectType": "UserReservation",
		   "restaurantNo": "`+ restaurantNo +`",
		   "reservationStatus": "CheckOut Completed"
		}
	 }`
	restCustomerListIter, err :=  stub.GetQueryResult(stringQry)
	//restCustomerList, err := getDetailsFromQuery(stub, objectUserReservation, "restaurantNo", restaurantNo)
	if err != nil {			
		return shim.Error(err.Error())
	}
	restCustomerList, err := constructQueryResponseFromQueryIterator(restCustomerListIter)
	if err != nil {
		return shim.Error(err.Error())
	}
	json.Unmarshal([]byte(restCustomerList.String()), &userReservation)
	fmt.Println(userReservation)
	fmt.Println("after useer Reservation")
	bArrayMemberAlreadyWritten := false
	i := 0
	customerIDArray := make([]string, len(userReservation))
	for i < len(userReservation) {
		customerIDArray = append(customerIDArray, userReservation[i].UserID)
		i++
	}
	fmt.Println(customerIDArray)
	customerID := removeDuplicatesUnordered(customerIDArray[i:])
	fmt.Println(customerID)
	i = 0
	for i < len(customerID) {
		customerID := customerID[i]
		//get the user details and Reservation for the specific restaurant
		//[{"objectType":"UserReservation","reservationNo":1,"reservationStatus":"CheckOut Completed","restSeatNo":"Murp1","restaurantNo":"RES1","userID":"USER1"}]
		userAndResrvbuffer, err := getCustomerRestdetailsByuserID(stub, restaurantNo,customerID)
		if err != nil {			
			return shim.Error(err.Error())
		}
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString(string(userAndResrvbuffer))
		bArrayMemberAlreadyWritten = true
		i++

	}

	buffer.WriteString("]")

	return shim.Success(buffer.Bytes())
}


