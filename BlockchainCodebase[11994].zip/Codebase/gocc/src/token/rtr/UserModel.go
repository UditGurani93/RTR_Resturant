package main

// User structure manages the state 
type User struct {
	ObjectType 							string	 `json:"objectType"` 
	UserID		   						string   `json:"userID"`
	UserName  							string   `json:"userName"`
	MemberShip							string   `json:"memberShip"`
}


