package main

import (
	// The shim package
	"github.com/hyperledger/fabric/core/chaincode/shim"
 
	// peer.Response is in the peer package
	"github.com/hyperledger/fabric/protos/peer"
	//"fmt"
	"encoding/json"
	"bytes"
 )
 
func (rtr *ReturntoRestaurantChaincode) QueryAllReservationByUsedID(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	userID := args[0]
	//var data UserReservation
	//var reservationNo []string
	stringQry := `{
		"selector": {
		   "objectType": "UserReservation",
		   "userID": "`+userID+`"
		}
	 }`
	userReservationResultsIterator, err := stub.GetQueryResult(stringQry)
	if err != nil {
		return shim.Error(err.Error())
	}
	buffer, err := constructQueryResponseFromIterator(userReservationResultsIterator)
	if err != nil {
		return shim.Error(err.Error())
	}
	//_ = json.Unmarshal(buffer, &data)
	// i := 0
	// for i < len(data) {
	// 	reservationNo[i] = data[i].ReservationNo
	// }
	// fmt.Println(reservationNo)
	return shim.Success(buffer.Bytes())
}

// set-chain-env.sh  -q '{"Args": ["QueryByFieldValue","UserReservation", "userID", "USER0" ] }' 
// chain.sh 
func (rtr *ReturntoRestaurantChaincode) QueryByFieldValue(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	objectType := args[0]
	fieldName := args[1]
	fieldValue := args[2]
	buffer, err := getDetailsFromQuery(stub, objectType, fieldName, fieldValue)
	if err != "" {
		return shim.Error(err)
	}
	//_ = json.Unmarshal(buffer, &data)
	// i := 0
	// for i < len(data) {
	// 	reservationNo[i] = data[i].ReservationNo
	// }
	// fmt.Println(reservationNo)
	return shim.Success(buffer)
}

func (rtr *ReturntoRestaurantChaincode) GetReservationDeatilsByResvNo(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	reservationNo := args[0]
	buffer, err := 	getReservationDetailsByReservationNo(stub, reservationNo)
	if err != "" {
		return shim.Error(err)
	}
	return shim.Success(buffer.Bytes())
}


func getReservationDetailsByReservationNo(stub shim.ChaincodeStubInterface, reservationNo string) (*bytes.Buffer, string) {
	var userReservation UserReservation
	//var reservationDetails ReservationDetails

	var buffer bytes.Buffer
	var jsonResp string
	buffer.WriteString("[")

	indexName := "objectType~reservationNo"
	reservationIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectUserReservation, reservationNo})
	
	resAsBytes, err := stub.GetState(reservationIndexKey)
	if err != nil {
		errstr := "Failed to get state for " + reservationNo + " : "+ err.Error()
		return nil, errstr
	} else if resAsBytes == nil {
		jsonResp = "{\"Error\":\"Reservation does not exist: " + reservationNo + "\"}"
		return nil, jsonResp
	}
	err = json.Unmarshal([]byte(resAsBytes), &userReservation)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of: " + reservationNo + "\"}"
		return nil, jsonResp
	}
	buffer.WriteString(string(resAsBytes))
	
	//Now We will get the ReservaationDetails
	reservationDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeReservationDetails, reservationNo})
	
	resDetAsBytes, err := stub.GetState(reservationDetailsIndexKey)
	if err != nil {
		errstr := "Failed to get state for " + reservationNo + " details : "+ err.Error()
		return nil, errstr
	} else if resDetAsBytes == nil {
		jsonResp = "{\"Error\":\"Restaurant Details does not exist: " + reservationNo + "\"}"
		return nil, jsonResp
	}
	buffer.WriteString("," + string(resDetAsBytes))
	

	//Now we will get the Seat Deails
	indexName = "objectType~restSeatNo"
	restSeatNo := userReservation.RestSeatNo
	 
	seatDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatDetails, restSeatNo})
	
	seatDetAsBytes, err := stub.GetState(seatDetailsIndexKey)
	if err != nil {
		errstr := "Failed to get state for " + restSeatNo + " seat details : "+ err.Error()
		return nil, errstr
	} else if seatDetAsBytes == nil {
		jsonResp = "{\"Error\":\"Seat Details does not exist: " + restSeatNo + "\"}"
		return nil, jsonResp
	}
	buffer.WriteString("," + string(seatDetAsBytes))
	buffer.WriteString("]")

	return &buffer, ""

}



func getDetailsFromQuery(stub shim.ChaincodeStubInterface, objectType string, fieldName string, fieldValue string) ([]byte, string) {
	//var buffer bytes.Buffer
	stringQry := `{
		"selector": {
		   "objectType": "`+ objectType +`",
		   "`+fieldName+`": "`+fieldValue+`"
		}
	 }`
	userReservationResultsIterator, err := stub.GetQueryResult(stringQry)
		if err != nil {
			return nil, err.Error()
		}
	buffer, err := constructQueryResponseFromQueryIterator(userReservationResultsIterator)
	if err != nil {
		return nil, err.Error()
	}
	//_ = json.Unmarshal(buffer, &data)
	// i := 0
	// for i < len(data) {
	// 	reservationNo[i] = data[i].ReservationNo
	// }
	// fmt.Println(reservationNo)
	return buffer.Bytes(), ""
}



func (rtr *ReturntoRestaurantChaincode) GetHistoryOfSeatBySeatNo(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	reservationNo := args[0]
	indexName := "objectType~reservationNo"
	seatResrvDetailsIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectTypeSeatReservationDetails, reservationNo})
	if err != nil {
		return shim.Error(err.Error())
	}
	
	response, err := getHistoryByKey(stub, seatResrvDetailsIndexKey)
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success([]byte(response))
}

func getHistoryByKey(stub shim.ChaincodeStubInterface, key string) (string, error) {
	
	historyQueryIterator, err := stub.GetHistoryForKey(key)
	
	// In case of error - return error
	if err != nil {
		return  "", err
	}
	resultJSON := "["
	counter := 0
	// Start a loop with check for more rows
	for historyQueryIterator.HasNext() {

		// Get the next record
		resultModification, err := historyQueryIterator.Next()

		if err != nil {
			return "", err
		}
		
		// Append the data to local variable
		data := string(resultModification.GetValue())
		if counter > 0 {
			data = ", "+data
		}
		resultJSON += data
		counter++
	}

	// Close the iterator
	historyQueryIterator.Close()

	// finalize the return string
	resultJSON += "]"
	resultJSON = "{\"Seat History\":" + resultJSON  + "}"
	
	return resultJSON, nil

}

