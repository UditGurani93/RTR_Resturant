package main

// User structure manages the state 

//"objectType~reservationNo"
//"objectType~userID~restSeatNo"
type UserReservation struct {
	ObjectType 							string	 `json:"objectType"` 
	UserID		   						string   `json:"userID"`
	//RestSeatNo							string    `json:"restSeatNo"`
	ReservationNo						int		   `json:"reservationNo"`
	ReservationStatus					string	 `json:"reservationStatus"`
	RestaurantNo   						string 	`json:"restaurantNo"`
	
}

// User structure manages the state 
type UserRestaurantFeedback struct {
	ObjectType 							string	 `json:"objectType"` 
	RestaurantNo   						string 	 `json:"restaurantNo"`
	ReservationNo						string   `json:"reservationNo"`
	Q1									string	 `json:"q1"`
	Q2									string	 `json:"q2"`
	Q3									string	 `json:"q3"`
	Q4									string	 `json:"q4"`
	Q5									string	 `json:"q5"`
	RestaurantPreference				int   `json:"restaurantPreference"`
}

// type Users struct {
//     Users []User `json:"users"`
// }
// const ResNoSeatNoIndexKey = "restaurantNo~seatNo"
// const objectTypeSeatReservation = "SeatReservation"
// const objectTypeSeatReservationDetails = "SeatReservationDetails"
// const objectTypeReservationDetails = "ReservationDetails"
// const objectUserReservation = "UserReservation"
// const objectTypeSeatDetails = "SeatDetails"
	
// User structure manages the state 
// type SeatReservation struct {
// 	ObjectType 							string	 `json:"objectType"` 
// 	ReservationNo						string   `json:"reservationNo"`
// 	SeatNo								string   `json:"seatNo"`
// 	UserThermalTemperature				string   `json:"userThermalTemperature"`
// 	UserCheckInTime						string   `json:"userCheckInTime"`
// 	UserCheckOutTime					string   `json:"userCheckOutTime"`			
// }

//"objectType~reservationNo"
type ReservationDetails struct {
	ObjectType 							string	 `json:"objectType"` 
	ReservationNo						string   `json:"reservationNo"`
	UserBodyTemperature					string   `json:"userBodyTemperature"`
	UserCheckInTime						string   `json:"userCheckInTime"`
	UserCheckOutTime					string   `json:"userCheckOutTime"`			
	SanitizationStartTime				string 	`json:"sanitizationStartTime"`
	SanitizationEndTime					string 	`json:"sanitizationEndTime"`
}

type SeatReservationDetails struct {
	ObjectType 							string 	`json:"objectType"` 
	ReservationNo   					string 	`json:"reservationNo"`	
	RestSeatNo							string  `json:"restSeatNo"`
	//CheckedIn, CheckedOut"Sanitzation Process Started", Sanitzation Process End, Now it is available to use
	ResrvSeatStatus						string  `json:"resrvSeatStatus"`
	Timestamp							string	`json:"timestamp"`
}

// "objectType~restSeatNo"
//"objectType~restaurantNo~seatN  o"
type SeatDetails struct {
	ObjectType 							string 	`json:"objectType"` 
	RestSeatNo							string  `json:"restSeatNo"`
	RestaurantNo   						string 	`json:"restaurantNo"`
	SeatNo								int  	`json:"seatNo"`
	//Available, Sanitization Process ,Seated,Seat Booked, Sanitization Pending
	SeatStatus							string  `json:"seatStatus"`
}

type UserCheckOut struct {
	ObjectType 							string 	`json:"objectType"` 
	ReservationNo   					string 	`json:"reservationNo"`	
	OfferNo								int		`json:"offerNo"`
}

type UserRestaurantDetailsResponse struct {
	UserID		   						string   `json:"userID"`
	UserName  							string   `json:"userName"`
	MemberShip							string   `json:"memberShip"`
	UserReservatons						[]string `json:"UserReservatons"`
	TotalUserReservaton					string	 `json:"totalUserReservaton"`
}
