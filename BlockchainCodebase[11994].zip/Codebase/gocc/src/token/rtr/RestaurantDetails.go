package main
import (
	// The shim package
	"github.com/hyperledger/fabric/core/chaincode/shim"
 
	// peer.Response is in the peer package
	"github.com/hyperledger/fabric/protos/peer"
	//"fmt"
	"encoding/json"
	"fmt"
	"strconv"
	"bytes"
 )

 const	objectTypeRestaurantOffers = "RestaurantOffers"


 func (rtr *ReturntoRestaurantChaincode) InitRestaurantOffer(stub shim.ChaincodeStubInterface) peer.Response {
 
	restaurantOffers := []RestaurantOffers{
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES0",PromoCode: "ABCD", OfferDecription : "For Prime Member", DiscountPercentage: "20", DiscountUpto:"600" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 4 ,UserReservationCount : "" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES0",PromoCode: "XYZ1", OfferDecription : "For Prime and who is having 5 Reservation checkout atleast", DiscountPercentage: "10", DiscountUpto:"400" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 3 ,UserReservationCount : "5" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES0",PromoCode: "PQRS", OfferDecription : "For 10 Reservation Checkout user", DiscountPercentage: "10", DiscountUpto:"300" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 2 ,UserReservationCount : "10" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES0",PromoCode: "1234", OfferDecription : "For All User", DiscountPercentage: "10", DiscountUpto:"50" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 1 ,UserReservationCount : "0" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES0",PromoCode: "4321", OfferDecription : "For Unregister User", DiscountPercentage: "5", DiscountUpto:"50" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 0 ,UserReservationCount : "0" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES0",PromoCode: "9884", OfferDecription : "For Prime and who is having 10 Reservation checkout atleast", DiscountPercentage: "20", DiscountUpto:"800" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 3 ,UserReservationCount : "10" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES0",PromoCode: "3422", OfferDecription : "For 20 Reservation Checkout user", DiscountPercentage: "20", DiscountUpto:"800" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 2 ,UserReservationCount : "20" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES0",PromoCode: "YXCV", OfferDecription : "For First time User who is having 0 checkout", DiscountPercentage: "15", DiscountUpto:"300" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 1 ,UserReservationCount : "0" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES1",PromoCode: "PLKJ", OfferDecription : "For Prime Member", DiscountPercentage: "25", DiscountUpto:"600" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 4 ,UserReservationCount : "" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES1",PromoCode: "QWER", OfferDecription : "For Prime and who is having 5 Reservation checkout atleast", DiscountPercentage: "10", DiscountUpto:"400" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 3 ,UserReservationCount : "5" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES1",PromoCode: "DSFS", OfferDecription : "For 10 Reservation Checkout user",DiscountPercentage: "10", DiscountUpto:"300" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 2 ,UserReservationCount : "10" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES1",PromoCode: "QWQE", OfferDecription : "For All User",  DiscountPercentage: "10", DiscountUpto:"50" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 1 ,UserReservationCount : "0" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES1",PromoCode: "SDFF", OfferDecription : "For Prime and who is having 10 Reservation checkout atleast",  DiscountPercentage: "20", DiscountUpto:"800" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 3 ,UserReservationCount : "10" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES1",PromoCode: "EWRW", OfferDecription : "For 20 Reservation Checkout user", DiscountPercentage: "20", DiscountUpto:"800" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 2 ,UserReservationCount : "20" },
		RestaurantOffers{ObjectType: objectTypeRestaurantOffers, RestaurantNo: "RES1",PromoCode: "FGHG", OfferDecription : "For First User who is having 0 checkout", DiscountPercentage: "15", DiscountUpto:"300" , OfferValidityStartDate: "" , OfferValidityEndDate: "", ValidFor : 1 ,UserReservationCount : "0" },
		}
	//User

	i := 0
	for i < len(restaurantOffers) {
		fmt.Println("i is ", i)
		restaurantOffers[i].OfferNo = i
		restaurantOffersAsBytes, _ := json.Marshal(restaurantOffers[i])
		indexName := "objectType~offerNo"

		key, _ := stub.CreateCompositeKey(indexName, []string{objectTypeRestaurantOffers, strconv.Itoa(restaurantOffers[i].OfferNo)})
		
		stub.PutState( key , restaurantOffersAsBytes)
		
		fmt.Println("Added Restaurant offer", restaurantOffers[i])
		i = i + 1
	}
	return shim.Success(nil)
}


func (rtr *ReturntoRestaurantChaincode) GetAllOffersByUserIDRestaurantNo(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	fmt.Println("userAndResrvbuffer")
		
	userID :=args[0]
	fmt.Println(userID)
	restaurantNo := args[1]
	fmt.Println(restaurantNo)
		
	var restaurantOffers = []RestaurantOffers{}
	var userReservArray UserRestaurantDetailsResponse

	restaurantOfferBytes, _ := getDetailsFromQuery(stub, objectTypeRestaurantOffers, "restaurantNo", restaurantNo)
	_ = json.Unmarshal(restaurantOfferBytes, &restaurantOffers)

	// {"userID" : "USER1", "userName" : "Mallik", "memberShip" : "Prime", "UserReservatons":["1","18"], "totalUserReservaton":2}
	userAndResrvbuffer, _ := getCustomerRestdetailsByuserID(stub, restaurantNo, userID)
	_ = json.Unmarshal([]byte(userAndResrvbuffer), &userReservArray)

	// membership := userReservArray[0].memberShip
	// userReservationCount := userReservArray[0].totalUserReservaton
	fmt.Println(userReservArray)
	fmt.Println("userAndResrvbuffer")
		
	fmt.Println(restaurantOffers)

	i :=0
	userValidFor := ""
	isAny := false
	membership := userReservArray.MemberShip
	userReservationCount := userReservArray.TotalUserReservaton
	fmt.Println(len(restaurantOffers))

	for i < len(restaurantOffers){
		isAny = false
		validFor := restaurantOffers[i].ValidFor
		miniResrvCount := restaurantOffers[i].UserReservationCount
		if membership == "Prime"{
			if validFor == 4 {
				userValidFor += "4"
				isAny = true
			}else if (validFor == 3 && userReservationCount >= miniResrvCount) {
				userValidFor += "3"
				isAny = true
			}
		}else if (validFor == 2 && userReservationCount >= miniResrvCount) {
			userValidFor += "2"
			isAny = true
		} else if validFor == 1{
			userValidFor += "1"	
			isAny = true
		} else if (validFor == 0 && userReservationCount == "0"){
			userValidFor += "0"
			isAny = true
		}
		//fmt.Println(i)
		if (i > 0 && isAny == true ){
			userValidFor = userValidFor + ","
		}
		i++
			
	}

	qryString := `{
		"selector": {
		   "objectType": "RestaurantOffers",
		   "validFor": {
			  "$in": [`+userValidFor+`]
		   }
		}
	 }`

	 fmt.Println(qryString)
		
	 Iterator, err := stub.GetQueryResult(qryString)
	 if err != nil {
		return shim.Error(err.Error())
	 }
	 buffer, err := constructQueryResponseFromQueryIterator(Iterator)
	 if err != nil {
		return shim.Error(err.Error())
	 }
	 return shim.Success(buffer.Bytes())

}


func (rtr *ReturntoRestaurantChaincode) GetRestaurantSeatStatusbyRestaurantNo(stub shim.ChaincodeStubInterface, args []string ) peer.Response{
	restaurantNo := args[0]
	var seatDetails = []SeatDetails{}
	// var seatReservationDetails SeatReservationDetails
	// var userReservation UserReservation
	var buffer bytes.Buffer
	// var jsonResp string
	buffer.WriteString("[")


	seatDetailsResp, err := getDetailsFromQuery(stub, objectTypeSeatDetails, "restaurantNo", restaurantNo)
	if err != "" {
		return shim.Error(err)
	}
	json.Unmarshal([]byte(seatDetailsResp), &seatDetails)
	
	i := 0
	bArrayMemberAlreadyWritten := false
	for i < len(seatDetails){
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		// buffer.WriteString("[")
		seatStatus := seatDetails[i].SeatStatus
		if seatStatus != "Available" {
			 restSeatNo := seatDetails[i].RestSeatNo
			 seatNo := seatDetails[i].SeatNo
			 //seatStatus := seatDetails[i].SeatStatus
			 buffer.WriteString("{\"restSeatNo\": \"")
			 buffer.WriteString(restSeatNo)
			 buffer.WriteString("\",")
			 buffer.WriteString("\"seatNo\": \"")
			 buffer.WriteString(strconv.Itoa(seatNo))
			 buffer.WriteString("\",")
			 buffer.WriteString("\"seatStatus\": \"")
			 buffer.WriteString(seatStatus)
			 buffer.WriteString("\",")

			// seatReservationDetailsResp, _ := getReservationsDetailsNotChekcedOutFromQuery(stub, objectTypeSeatReservationDetails, "restSeatNo", restSeatNo, "resrvSeatStatus", "CheckOut" )
			// json.Unmarshal([]byte(seatReservationDetailsResp), &seatReservationDetails)
			// reservationNO := seatReservationDetails.ReservationNo

			// indexName := "objectType~reservationNo"
			// userReservationIndexKey, err := stub.CreateCompositeKey(indexName, []string{objectUserReservation, reservationNo})
			// userReservationAsByte, err := stub.GetState(userReservationIndexKey)
			// json.Unmarshal([]byte(userReservationAsByte), &userReservation)

			// userID := userReservation.UserID
			reservationNo, userID := getAllReservationAndSUserIDBySeatID(stub, restSeatNo)
			reservBuffer, _ := getReservationDetailsByReservationNo(stub, reservationNo)
			
			buffer.WriteString("\"ReservationDetails\":")
			buffer.WriteString(reservBuffer.String())
			buffer.WriteString(",")
			buffer.WriteString("\"UserDetails\":")
			fmt.Println("bufferByte")
			userAndResrvbuffer, _ := getCustomerRestdetailsByuserID(stub, restaurantNo, userID)
			if userAndResrvbuffer != nil {
				buffer.WriteString(string(userAndResrvbuffer))
				//fmt.Println(string(userAndResrvbuffer))
				buffer.WriteString("}")
				
			} else{
				bufferByte, _ := getUserDetailsByUserID(stub, userID)
				buffer.WriteString(string(bufferByte))
				//fmt.Println(string(bufferByte))
			}
			
		} else{
			seatDetailsAsBytes, _ := json.Marshal(seatDetails[i])
			buffer.WriteString(string(seatDetailsAsBytes))
		}
		
		// buffer.WriteString("]")
		
		bArrayMemberAlreadyWritten = true
		i++
	}
	//_ = json.Unmarshal(buffer, &data)
	// i := 0
	// for i < len(data) {
	// 	reservationNo[i] = data[i].ReservationNo
	// }
	//fmt.Println(buffer.String())
	buffer.WriteString("]")
	// fmt.Println(reservationNo)
	return shim.Success(buffer.Bytes())

}

