docker-compose -f docker-compose-ca.yaml down
rm -rf ./server/*
rm -rf ./client/*
cp fabric-ca-server-config.yaml ./server
docker-compose -f docker-compose-ca.yaml up -d

sleep 3s

# Bootstrap enrollment
export FABRIC_CA_CLIENT_HOME=$PWD/client/caserver/admin
fabric-ca-client enroll -u http://admin:adminpw@localhost:7054


######################
# Admin registration #
######################
echo "Registering: ncr-admin"
ATTRIBUTES='"hf.Registrar.Roles=peer,user,client","hf.AffiliationMgr=true","hf.Revoker=true","hf.Registrar.Attributes=*"'
fabric-ca-client register --id.type client --id.name ncr-admin --id.secret adminpw --id.affiliation ncr --id.attrs $ATTRIBUTES

# 3. Register chipotle-admin
echo "Registering: chipotle-admin"
ATTRIBUTES='"hf.Registrar.Roles=peer,user,client","hf.AffiliationMgr=true","hf.Revoker=true","hf.Registrar.Attributes=*"'
fabric-ca-client register --id.type client --id.name chipotle-admin --id.secret adminpw --id.affiliation chipotle --id.attrs $ATTRIBUTES

# 3. Register murphy-admin
echo "Registering: murphy-admin"
ATTRIBUTES='"hf.Registrar.Roles=peer,user,client","hf.AffiliationMgr=true","hf.Revoker=true","hf.Registrar.Attributes=*"'
fabric-ca-client register --id.type client --id.name murphy-admin --id.secret adminpw --id.affiliation murphy --id.attrs $ATTRIBUTES

# 3. Register riogrande-admin
echo "Registering: riogrande-admin"
ATTRIBUTES='"hf.Registrar.Roles=peer,user,client","hf.AffiliationMgr=true","hf.Revoker=true","hf.Registrar.Attributes=*"'
fabric-ca-client register --id.type client --id.name riogrande-admin --id.secret adminpw --id.affiliation riogrande --id.attrs $ATTRIBUTES


# 3. Register metropolitan-admin
echo "Registering: metropolitan-admin"
ATTRIBUTES='"hf.Registrar.Roles=peer,user,client","hf.AffiliationMgr=true","hf.Revoker=true","hf.Registrar.Attributes=*"'
fabric-ca-client register --id.type client --id.name metropolitan-admin --id.secret adminpw --id.affiliation metropolitan --id.attrs $ATTRIBUTES

# 3. Register firehousesubs-admin
echo "Registering: firehousesubs-admin"
ATTRIBUTES='"hf.Registrar.Roles=peer,user,client","hf.AffiliationMgr=true","hf.Revoker=true","hf.Registrar.Attributes=*"'
fabric-ca-client register --id.type client --id.name firehousesubs-admin --id.secret adminpw --id.affiliation firehousesubs --id.attrs $ATTRIBUTES

# 3. Register leospizzaria-admin
echo "Registering: leospizzaria-admin"
ATTRIBUTES='"hf.Registrar.Roles=peer,user,client","hf.AffiliationMgr=true","hf.Revoker=true","hf.Registrar.Attributes=*"'
fabric-ca-client register --id.type client --id.name leospizzaria-admin --id.secret adminpw --id.affiliation leospizzaria --id.attrs $ATTRIBUTES


# 3. Register montanagrill-admin
echo "Registering: montanagrill-admin"
ATTRIBUTES='"hf.Registrar.Roles=peer,user,client","hf.AffiliationMgr=true","hf.Revoker=true","hf.Registrar.Attributes=*"'
fabric-ca-client register --id.type client --id.name montanagrill-admin --id.secret adminpw --id.affiliation montanagrill --id.attrs $ATTRIBUTES



# 4. Register orderer-admin
echo "Registering: orderer-admin"
ATTRIBUTES='"hf.Registrar.Roles=orderer"'
fabric-ca-client register --id.type client --id.name orderer-admin --id.secret adminpw --id.affiliation orderer --id.attrs $ATTRIBUTES


####################
# Admin Enrollment #
####################
export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/admin
fabric-ca-client enroll -u http://ncr-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/chipotle/admin
fabric-ca-client enroll -u http://chipotle-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/murphy/admin
fabric-ca-client enroll -u http://murphy-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/riogrande/admin
fabric-ca-client enroll -u http://riogrande-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/metropolitan/admin
fabric-ca-client enroll -u http://metropolitan-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/firehousesubs/admin
fabric-ca-client enroll -u http://firehousesubs-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/leospizzaria/admin
fabric-ca-client enroll -u http://leospizzaria-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/montanagrill/admin
fabric-ca-client enroll -u http://montanagrill-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts



export FABRIC_CA_CLIENT_HOME=$PWD/client/orderer/admin
fabric-ca-client enroll -u http://orderer-admin:adminpw@localhost:7054
mkdir -p $FABRIC_CA_CLIENT_HOME/msp/admincerts
cp $FABRIC_CA_CLIENT_HOME/../../caserver/admin/msp/signcerts/*  $FABRIC_CA_CLIENT_HOME/msp/admincerts

#################
# Org MSP Setup #
#################
# Path to the CA certificate
ROOT_CA_CERTIFICATE=./server/ca-cert.pem
mkdir -p ./client/orderer/msp/admincerts
mkdir ./client/orderer/msp/cacerts
mkdir ./client/orderer/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/orderer/msp/cacerts
cp ./client/orderer/admin/msp/signcerts/* ./client/orderer/msp/admincerts   

mkdir -p ./client/ncr/msp/admincerts
mkdir ./client/ncr/msp/cacerts
mkdir ./client/ncr/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/ncr/msp/cacerts
cp ./client/ncr/admin/msp/signcerts/* ./client/ncr/msp/admincerts   

mkdir -p ./client/chipotle/msp/admincerts
mkdir ./client/chipotle/msp/cacerts
mkdir ./client/chipotle/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/chipotle/msp/cacerts
cp ./client/chipotle/admin/msp/signcerts/* ./client/chipotle/msp/admincerts   

mkdir -p ./client/murphy/msp/admincerts
mkdir ./client/murphy/msp/cacerts
mkdir ./client/murphy/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/murphy/msp/cacerts
cp ./client/murphy/admin/msp/signcerts/* ./client/murphy/msp/admincerts   

mkdir -p ./client/riogrande/msp/admincerts
mkdir ./client/riogrande/msp/cacerts
mkdir ./client/riogrande/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/riogrande/msp/cacerts
cp ./client/riogrande/admin/msp/signcerts/* ./client/riogrande/msp/admincerts   

mkdir -p ./client/metropolitan/msp/admincerts
mkdir ./client/metropolitan/msp/cacerts
mkdir ./client/metropolitan/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/metropolitan/msp/cacerts
cp ./client/metropolitan/admin/msp/signcerts/* ./client/metropolitan/msp/admincerts   

mkdir -p ./client/firehousesubs/msp/admincerts
mkdir ./client/firehousesubs/msp/cacerts
mkdir ./client/firehousesubs/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/firehousesubs/msp/cacerts
cp ./client/firehousesubs/admin/msp/signcerts/* ./client/firehousesubs/msp/admincerts   

mkdir -p ./client/leospizzaria/msp/admincerts
mkdir ./client/leospizzaria/msp/cacerts
mkdir ./client/leospizzaria/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/leospizzaria/msp/cacerts
cp ./client/leospizzaria/admin/msp/signcerts/* ./client/leospizzaria/msp/admincerts   

mkdir -p ./client/montanagrill/msp/admincerts
mkdir ./client/montanagrill/msp/cacerts
mkdir ./client/montanagrill/msp/keystore
cp $ROOT_CA_CERTIFICATE ./client/montanagrill/msp/cacerts
cp ./client/montanagrill/admin/msp/signcerts/* ./client/montanagrill/msp/admincerts   



######################
# Orderer Enrollment #
######################
export FABRIC_CA_CLIENT_HOME=$PWD/client/orderer/admin
fabric-ca-client register --id.type orderer --id.name orderer --id.secret adminpw --id.affiliation orderer 
export FABRIC_CA_CLIENT_HOME=$PWD/client/orderer/orderer
fabric-ca-client enroll -u http://orderer:adminpw@localhost:7054
cp -a $PWD/client/orderer/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

####################
# Peer Enrollments #
####################
export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/admin
fabric-ca-client register --id.type peer --id.name ncr-peer1 --id.secret adminpw --id.affiliation ncr 
export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/peer1
fabric-ca-client enroll -u http://ncr-peer1:adminpw@localhost:7054
cp -a $PWD/client/ncr/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/chipotle/admin
fabric-ca-client register --id.type peer --id.name chipotle-peer1 --id.secret adminpw --id.affiliation chipotle
export FABRIC_CA_CLIENT_HOME=$PWD/client/chipotle/peer1
fabric-ca-client enroll -u http://chipotle-peer1:adminpw@localhost:7054
cp -a $PWD/client/chipotle/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/murphy/admin
fabric-ca-client register --id.type peer --id.name murphy-peer1 --id.secret adminpw --id.affiliation murphy
export FABRIC_CA_CLIENT_HOME=$PWD/client/murphy/peer1
fabric-ca-client enroll -u http://murphy-peer1:adminpw@localhost:7054
cp -a $PWD/client/murphy/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/riogrande/admin
fabric-ca-client register --id.type peer --id.name riogrande-peer1 --id.secret adminpw --id.affiliation riogrande
export FABRIC_CA_CLIENT_HOME=$PWD/client/riogrande/peer1
fabric-ca-client enroll -u http://riogrande-peer1:adminpw@localhost:7054
cp -a $PWD/client/riogrande/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/metropolitan/admin
fabric-ca-client register --id.type peer --id.name metropolitan-peer1 --id.secret adminpw --id.affiliation metropolitan
export FABRIC_CA_CLIENT_HOME=$PWD/client/metropolitan/peer1
fabric-ca-client enroll -u http://metropolitan-peer1:adminpw@localhost:7054
cp -a $PWD/client/metropolitan/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/firehousesubs/admin
fabric-ca-client register --id.type peer --id.name firehousesubs-peer1 --id.secret adminpw --id.affiliation firehousesubs
export FABRIC_CA_CLIENT_HOME=$PWD/client/firehousesubs/peer1
fabric-ca-client enroll -u http://firehousesubs-peer1:adminpw@localhost:7054
cp -a $PWD/client/firehousesubs/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/leospizzaria/admin
fabric-ca-client register --id.type peer --id.name leospizzaria-peer1 --id.secret adminpw --id.affiliation leospizzaria
export FABRIC_CA_CLIENT_HOME=$PWD/client/leospizzaria/peer1
fabric-ca-client enroll -u http://leospizzaria-peer1:adminpw@localhost:7054
cp -a $PWD/client/leospizzaria/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts



export FABRIC_CA_CLIENT_HOME=$PWD/client/montanagrill/admin
fabric-ca-client register --id.type peer --id.name montanagrill-peer1 --id.secret adminpw --id.affiliation montanagrill
export FABRIC_CA_CLIENT_HOME=$PWD/client/montanagrill/peer1
fabric-ca-client enroll -u http://montanagrill-peer1:adminpw@localhost:7054
cp -a $PWD/client/montanagrill/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts




##############################
# User Enrollments Ncr only #
##############################
export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","app.user.role=prime:ecert","department=user:ecert"'
fabric-ca-client register --id.type user --id.name anuj --id.secret pw --id.affiliation ncr --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/anuj
fabric-ca-client enroll -u http://anuj:pw@localhost:7054
cp -a $PWD/client/ncr/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","app.user.role=normal:ecert","department=user:ecert"'
fabric-ca-client register --id.type user --id.name mallik --id.secret pw --id.affiliation ncr --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/mallik
fabric-ca-client enroll -u http://mallik:pw@localhost:7054
cp -a $PWD/client/ncr/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=system:ecert","app.system.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name systemAdmin --id.secret pw --id.affiliation ncr --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/systemAdmin
fabric-ca-client enroll -u http://systemAdmin:pw@localhost:7054
cp -a $PWD/client/ncr/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=nonuser:ecert","app.nonuser.role=nonuser:ecert"'
fabric-ca-client register --id.type user --id.name nonuser --id.secret pw --id.affiliation ncr --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/ncr/nonuser
fabric-ca-client enroll -u http://nonuser:pw@localhost:7054
cp -a $PWD/client/ncr/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts



export FABRIC_CA_CLIENT_HOME=$PWD/client/chipotle/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=frontoffice:ecert","app.frontoffice.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name frontofficeAdminA --id.secret pw --id.affiliation chipotle --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/chipotle/frontofficeAdminA
fabric-ca-client enroll -u http://frontofficeAdminA:pw@localhost:8054
cp -a $PWD/client/chipotle/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/chipotle/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=service:ecert","app.service.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name ServiceAdminA --id.secret pw --id.affiliation chipotle --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/chipotle/ServiceAdminA
fabric-ca-client enroll -u http://ServiceAdminA:pw@localhost:8054
cp -a $PWD/client/chipotle/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/murphy/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=frontoffice:ecert","app.frontoffice.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name frontofficeAdminB --id.secret pw --id.affiliation murphy --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/murphy/frontofficeAdminB
fabric-ca-client enroll -u http://frontofficeAdminB:pw@localhost:9054
cp -a $PWD/client/murphy/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/murphy/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=service:ecert","app.service.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name ServiceAdminB --id.secret pw --id.affiliation murphy --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/murphy/ServiceAdminB
fabric-ca-client enroll -u http://ServiceAdminB:pw@localhost:9054
cp -a $PWD/client/murphy/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/riogrande/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=frontoffice:ecert","app.frontoffice.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name frontofficeAdminB --id.secret pw --id.affiliation riogrande --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/riogrande/frontofficeAdminB
fabric-ca-client enroll -u http://frontofficeAdminB:pw@localhost:9054
cp -a $PWD/client/riogrande/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/riogrande/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=service:ecert","app.service.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name ServiceAdminB --id.secret pw --id.affiliation riogrande --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/riogrande/ServiceAdminB
fabric-ca-client enroll -u http://ServiceAdminB:pw@localhost:9054
cp -a $PWD/client/riogrande/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/metropolitan/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=frontoffice:ecert","app.frontoffice.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name frontofficeAdminA --id.secret pw --id.affiliation metropolitan --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/metropolitan/frontofficeAdminA
fabric-ca-client enroll -u http://frontofficeAdminA:pw@localhost:2254
cp -a $PWD/client/metropolitan/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/metropolitan/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=service:ecert","app.service.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name ServiceAdminA --id.secret pw --id.affiliation metropolitan --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/metropolitan/ServiceAdminA
fabric-ca-client enroll -u http://ServiceAdminA:pw@localhost:2254
cp -a $PWD/client/metropolitan/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/firehousesubs/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=frontoffice:ecert","app.frontoffice.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name frontofficeAdminB --id.secret pw --id.affiliation firehousesubs --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/firehousesubs/frontofficeAdminB
fabric-ca-client enroll -u http://frontofficeAdminB:pw@localhost:3354
cp -a $PWD/client/firehousesubs/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/firehousesubs/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=service:ecert","app.service.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name ServiceAdminB --id.secret pw --id.affiliation firehousesubs --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/firehousesubs/ServiceAdminB
fabric-ca-client enroll -u http://ServiceAdminB:pw@localhost:3354
cp -a $PWD/client/firehousesubs/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts


export FABRIC_CA_CLIENT_HOME=$PWD/client/leospizzaria/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=frontoffice:ecert","app.frontoffice.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name frontofficeAdminB --id.secret pw --id.affiliation leospizzaria --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/leospizzaria/frontofficeAdminB
fabric-ca-client enroll -u http://frontofficeAdminB:pw@localhost:4454
cp -a $PWD/client/leospizzaria/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/leospizzaria/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=service:ecert","app.service.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name ServiceAdminB --id.secret pw --id.affiliation leospizzaria --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/leospizzaria/ServiceAdminB
fabric-ca-client enroll -u http://ServiceAdminB:pw@localhost:4454
cp -a $PWD/client/leospizzaria/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts




export FABRIC_CA_CLIENT_HOME=$PWD/client/montanagrill/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=frontoffice:ecert","app.frontoffice.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name frontofficeAdminB --id.secret pw --id.affiliation montanagrill --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/montanagrill/frontofficeAdminB
fabric-ca-client enroll -u http://frontofficeAdminB:pw@localhost:5554
cp -a $PWD/client/montanagrill/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts

export FABRIC_CA_CLIENT_HOME=$PWD/client/montanagrill/admin
ATTRIBUTES='"hf.AffiliationMgr=false:ecert","hf.Revoker=false:ecert","department=service:ecert","app.service.role=admin:ecert"'
fabric-ca-client register --id.type user --id.name ServiceAdminB --id.secret pw --id.affiliation montanagrill --id.attrs $ATTRIBUTES
export FABRIC_CA_CLIENT_HOME=$PWD/client/montanagrill/ServiceAdminB
fabric-ca-client enroll -u http://ServiceAdminB:pw@localhost:5554
cp -a $PWD/client/montanagrill/admin/msp/signcerts  $FABRIC_CA_CLIENT_HOME/msp/admincerts




# Shutdown CA
docker-compose -f docker-compose-ca.yaml down

# Setup network config
export FABRIC_CFG_PATH=$PWD/config
configtxgen -outputBlock  ./config/orderer/dining-genesis.block -channelID ordererchannel  -profile DiningOrdererGenesis
configtxgen -outputCreateChannelTx  ./config/diningchannel.tx -channelID diningchannel  -profile DiningChannel

ANCHOR_UPDATE_TX=./config/dining-anchor-update-ncr.tx
configtxgen -profile DiningChannel -outputAnchorPeersUpdate $ANCHOR_UPDATE_TX -channelID diningchannel -asOrg NcrMSP

ANCHOR_UPDATE_TX=./config/dining-anchor-update-chipotle.tx
configtxgen -profile DiningChannel -outputAnchorPeersUpdate $ANCHOR_UPDATE_TX -channelID diningchannel -asOrg ChipotleMSP

ANCHOR_UPDATE_TX=./config/dining-anchor-update-murphy.tx
configtxgen -profile DiningChannel -outputAnchorPeersUpdate $ANCHOR_UPDATE_TX -channelID diningchannel -asOrg MurphyMSP


ANCHOR_UPDATE_TX=./config/dining-anchor-update-riogrande.tx
configtxgen -profile DiningChannel -outputAnchorPeersUpdate $ANCHOR_UPDATE_TX -channelID diningchannel -asOrg RioGrandeMSP


ANCHOR_UPDATE_TX=./config/dining-anchor-update-metropolitan.tx
configtxgen -profile DiningChannel -outputAnchorPeersUpdate $ANCHOR_UPDATE_TX -channelID diningchannel -asOrg MetropolitanMSP

ANCHOR_UPDATE_TX=./config/dining-anchor-update-firehousesubs.tx
configtxgen -profile DiningChannel -outputAnchorPeersUpdate $ANCHOR_UPDATE_TX -channelID diningchannel -asOrg FirehousesubsMSP


ANCHOR_UPDATE_TX=./config/dining-anchor-update-leospizzaria.tx
configtxgen -profile DiningChannel -outputAnchorPeersUpdate $ANCHOR_UPDATE_TX -channelID diningchannel -asOrg LeospizzariaMSP



ANCHOR_UPDATE_TX=./config/dining-anchor-update-montanagrill.tx
configtxgen -profile DiningChannel -outputAnchorPeersUpdate $ANCHOR_UPDATE_TX -channelID diningchannel -asOrg MontanagrillMSP

