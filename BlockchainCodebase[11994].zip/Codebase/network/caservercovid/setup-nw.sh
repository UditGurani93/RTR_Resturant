#!/bin/bash

#docker-compose -f docker-compose.couchdb.yaml  down
#docker-compose -f docker-compose.explorer.yaml down
docker-compose -f docker-compose.cadev.yaml -f docker-compose.couchdb.yaml -f docker-compose.explorer.yaml down

# REMOVE the dev- container images also - TBD
docker rm $(docker ps -a -q)            &> /dev/null
docker rmi $(docker images dev-* -q)    &> /dev/null
sudo rm -rf $HOME/ledgers/ca &> /dev/null
export FABRIC_CFG_PATH=$PWD/config

docker-compose -f docker-compose.cadev.yaml  -f docker-compose.couchdb.yaml -f docker-compose.explorer.yaml up -d
#docker-compose -f docker-compose.couchdb.yaml  up -d
#docker-compose -f docker-compose.dev.yaml  up -d
#docker-compose -f docker-compose.base.yaml  up -d
#docker-compose -f docker-compose.explorer.yaml  up -d
sleep 10s
SLEEP_TIME=7s

echo    '========= Submitting txn for channel creation as NcrAdmin ============'
export CHANNEL_TX_FILE=./config/dining-channel.tx
export ORDERER_ADDRESS=orderer.ncr.com:7050
# export FABRIC_LOGGING_SPEC=DEBUG
export CORE_PEER_LOCALMSPID=NcrMSP
export CORE_PEER_MSPCONFIGPATH=$PWD/client/ncr/admin/msp
export CORE_PEER_ADDRESS=ncr-peer1.ncr.com:7051
peer channel create -o $ORDERER_ADDRESS -c diningchannel -f ./config/diningchannel.tx

sleep $SLEEP_TIME

echo    '========= Joining the ncr-peer1 to Dining channel ============'
Dining_CHANNEL_BLOCK=./diningchannel.block
export CORE_PEER_ADDRESS=ncr-peer1.ncr.com:7051
peer channel join -o $ORDERER_ADDRESS -b $Dining_CHANNEL_BLOCK
# Update anchor peer on channel for ncr
# sleep  3s
sleep $SLEEP_TIME
ANCHOR_UPDATE_TX=./config/dining-anchor-update-ncr.tx
peer channel update -o $ORDERER_ADDRESS -c diningchannel -f $ANCHOR_UPDATE_TX

echo    '========= Joining the chipotle-peer1 to Dining channel ============'
# peer channel fetch config $Dining_CHANNEL_BLOCK -o $ORDERER_ADDRESS -c diningchannel
export CORE_PEER_LOCALMSPID=ChipotleMSP
ORG_NAME=chipotle.com
export CORE_PEER_ADDRESS=chipotle-peer1.chipotle.com:8051
export CORE_PEER_MSPCONFIGPATH=$PWD/client/chipotle/admin/msp
peer channel join -o $ORDERER_ADDRESS -b $Dining_CHANNEL_BLOCK
# Update anchor peer on channel for chipotle
sleep  $SLEEP_TIME
ANCHOR_UPDATE_TX=./config/dining-anchor-update-chipotle.tx
peer channel update -o $ORDERER_ADDRESS -c diningchannel -f $ANCHOR_UPDATE_TX

echo    '========= Joining the murphy-peer1 to Dining channel ============'
# peer channel fetch config $Dining_CHANNEL_BLOCK -o $ORDERER_ADDRESS -c diningchannel
export CORE_PEER_LOCALMSPID=MurphyMSP
ORG_NAME=murphy.com
export CORE_PEER_ADDRESS=murphy-peer1.murphy.com:9051
export CORE_PEER_MSPCONFIGPATH=$PWD/client/murphy/admin/msp
peer channel join -o $ORDERER_ADDRESS -b $Dining_CHANNEL_BLOCK
# Update anchor peer on channel for murphy
sleep  $SLEEP_TIME
ANCHOR_UPDATE_TX=./config/dining-anchor-update-murphy.tx
peer channel update -o $ORDERER_ADDRESS -c diningchannel -f $ANCHOR_UPDATE_TX


echo    '========= Joining the riogrande-peer1 to Dining channel ============'
# peer channel fetch config $Dining_CHANNEL_BLOCK -o $ORDERER_ADDRESS -c diningchannel
export CORE_PEER_LOCALMSPID=RioGrandeMSP
ORG_NAME=riogrande.com
export CORE_PEER_ADDRESS=riogrande-peer1.riogrande.com:9951
export CORE_PEER_MSPCONFIGPATH=$PWD/client/riogrande/admin/msp
peer channel join -o $ORDERER_ADDRESS -b $Dining_CHANNEL_BLOCK
# Update anchor peer on channel for riogrande
sleep  $SLEEP_TIME
ANCHOR_UPDATE_TX=./config/dining-anchor-update-riogrande.tx
peer channel update -o $ORDERER_ADDRESS -c diningchannel -f $ANCHOR_UPDATE_TX

echo    '========= Joining the metropolitan-peer1 to Dining channel ============'
# peer channel fetch config $Dining_CHANNEL_BLOCK -o $ORDERER_ADDRESS -c diningchannel
export CORE_PEER_LOCALMSPID=MetropolitanMSP
ORG_NAME=metropolitan.com
export CORE_PEER_ADDRESS=metropolitan-peer1.metropolitan.com:2251
export CORE_PEER_MSPCONFIGPATH=$PWD/client/metropolitan/admin/msp
peer channel join -o $ORDERER_ADDRESS -b $Dining_CHANNEL_BLOCK
# Update anchor peer on channel for metropolitan
sleep  $SLEEP_TIME
ANCHOR_UPDATE_TX=./config/dining-anchor-update-metropolitan.tx
peer channel update -o $ORDERER_ADDRESS -c diningchannel -f $ANCHOR_UPDATE_TX

echo    '========= Joining the firehousesubs-peer1 to Dining channel ============'
# peer channel fetch config $Dining_CHANNEL_BLOCK -o $ORDERER_ADDRESS -c diningchannel
export CORE_PEER_LOCALMSPID=FirehousesubsMSP
ORG_NAME=firehousesubs.com
export CORE_PEER_ADDRESS=firehousesubs-peer1.firehousesubs.com:3351
export CORE_PEER_MSPCONFIGPATH=$PWD/client/firehousesubs/admin/msp
peer channel join -o $ORDERER_ADDRESS -b $Dining_CHANNEL_BLOCK
# Update anchor peer on channel for firehousesubs
sleep  $SLEEP_TIME
ANCHOR_UPDATE_TX=./config/dining-anchor-update-firehousesubs.tx
peer channel update -o $ORDERER_ADDRESS -c diningchannel -f $ANCHOR_UPDATE_TX


echo    '========= Joining the leospizzaria-peer1 to Dining channel ============'
# peer channel fetch config $Dining_CHANNEL_BLOCK -o $ORDERER_ADDRESS -c diningchannel
export CORE_PEER_LOCALMSPID=LeospizzariaMSP
ORG_NAME=leospizzaria.com
export CORE_PEER_ADDRESS=leospizzaria-peer1.leospizzaria.com:4451
export CORE_PEER_MSPCONFIGPATH=$PWD/client/leospizzaria/admin/msp
peer channel join -o $ORDERER_ADDRESS -b $Dining_CHANNEL_BLOCK
# Update anchor peer on channel for leospizzaria
sleep  $SLEEP_TIME
ANCHOR_UPDATE_TX=./config/dining-anchor-update-leospizzaria.tx
peer channel update -o $ORDERER_ADDRESS -c diningchannel -f $ANCHOR_UPDATE_TX


echo    '========= Joining the montanagrill-peer1 to Dining channel ============'
# peer channel fetch config $Dining_CHANNEL_BLOCK -o $ORDERER_ADDRESS -c diningchannel
export CORE_PEER_LOCALMSPID=MontanagrillMSP
ORG_NAME=montanagrill.com
export CORE_PEER_ADDRESS=montanagrill-peer1.montanagrill.com:5551
export CORE_PEER_MSPCONFIGPATH=$PWD/client/montanagrill/admin/msp
peer channel join -o $ORDERER_ADDRESS -b $Dining_CHANNEL_BLOCK
# Update anchor peer on channel for montanagrill
sleep  $SLEEP_TIME
ANCHOR_UPDATE_TX=./config/dining-anchor-update-montanagrill.tx
peer channel update -o $ORDERER_ADDRESS -c diningchannel -f $ANCHOR_UPDATE_TX


